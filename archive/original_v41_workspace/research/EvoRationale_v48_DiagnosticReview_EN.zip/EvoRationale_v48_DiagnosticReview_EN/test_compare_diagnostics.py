"""Provider-free integrity, regression-selection and nonmutation checks."""
from copy import deepcopy
import io
import json
from pathlib import Path
import tempfile
import subprocess
import sys
import unittest
import zipfile

from compare_diagnostics import compare, digest, read_zip, validate_snapshot


def encoded(value):
    return json.dumps(value, sort_keys=True).encode()


def fixture(version='46', tp=None, fp=None, fn=None):
    tp = tp if tp is not None else {('artifact-one', 'target-one', 'supports')}
    fp = fp if fp is not None else set()
    fn = fn if fn is not None else {('artifact-two', 'target-two', 'supersedes')}
    data = {'inputs/S0_RETROSPECTIVE_RUNTIME.json': encoded({'target': 'fixed'}),
            'inputs/POST_S0_EVIDENCE_RETROSPECTIVE_53.jsonl': b'{"content":"fixed source"}\n'}
    prep = {'runtime_s0_sha256': digest(data['inputs/S0_RETROSPECTIVE_RUNTIME.json']),
            'history_sha256': digest(data['inputs/POST_S0_EVIDENCE_RETROSPECTIVE_53.jsonl']),
            'frozen_s0_sha256': 'fixed-gold-state', 'frozen_manifest_sha256': 'fixed-gold-manifest',
            'v' + version + '_python_sha256': 'core-' + version,
            'models': {'judge': 'opaque-model', 'linker': 'opaque-model'},
            'budgets': {'max_rounds': 6}, 'investigation_profile': 'fixture-profile'}
    report = {'investigation_profile': 'fixture-profile',
              'verified_evidence': [{'artifact_id': a, 'decision_element_id': e, 'relation': r}
                                   for a, e, r in sorted(tp | fp)], 'budget_usage': {}}
    run_id = 'fixture-' + version
    checkpoint_path = 'checkpoints/' + run_id + '.json'
    data['DEV_PREP_MANIFEST.json'] = encoded(prep)
    data['run/report.json'] = encoded(report)
    data[checkpoint_path] = encoded({'run_id': run_id, 'report': report,
                                    'verified_links': report['verified_evidence'],
                                    'initial_state': {'target': 'fixed'}})
    manifest = {'run_id': run_id, 'mode': 'api', 'investigation_profile': 'fixture-profile',
                'report_sha256': digest(data['run/report.json']),
                'decision_sha256': prep['runtime_s0_sha256'], 'history_sha256': prep['history_sha256']}
    data['run/manifest.json'] = encoded(manifest)
    receipt = {'status': 'V' + version + '_DEV_HOSTED_RUN_COMPLETED_AND_HASHED',
               'run_id': run_id, 'mode': 'api', 'investigation_profile': 'fixture-profile',
               'prep_sha256': digest(data['DEV_PREP_MANIFEST.json']),
               'run_report_sha256': digest(data['run/report.json']),
               'run_manifest_sha256': digest(data['run/manifest.json']),
               'checkpoint_relative_path': checkpoint_path, 'checkpoint_sha256': digest(data[checkpoint_path]),
               'code_tree_sha256': prep['v' + version + '_python_sha256'],
               'model': prep['models'], 'nominal_budgets': prep['budgets']}
    data['RUN_RECEIPT.json'] = encoded(receipt)
    summary = {'tp': len(tp), 'fp': len(fp), 'fn': len(fn),
               'predicted_exact_triples': len(tp)+len(fp),
               'gold_positive_exact_triples': len(tp)+len(fn),
               'unscored_prediction_links_outside_hunk_universe': 0,
               'precision': len(tp)/(len(tp)+len(fp)) if tp | fp else 0.0,
               'recall': len(tp)/(len(tp)+len(fn)) if tp | fn else None,
               'f1': 2*len(tp)/(2*len(tp)+len(fp)+len(fn)) if tp | fp | fn else 0.0}
    metrics = {'status': 'V' + version + '_DEVELOPMENT_ONLY_POST_RUN_REFERENCE_COMPARISON',
               'investigation_profile': 'fixture-profile', 'budget_usage': {},
               'models': prep['models'], 'nominal_budgets': prep['budgets'],
               'verified_evidence_links': len(tp)+len(fp),
               'v' + version + '_run_report_sha256': receipt['run_report_sha256'],
               'v' + version + '_code_sha256': receipt['code_tree_sha256'],
               'frozen_s0_sha256': prep['frozen_s0_sha256'],
               'results': {'all': summary, 'baseline': summary}}
    data['score/metrics.json'] = encoded(metrics)
    lines = ['scope,verdict,hunk_id,atomic_s0_id,relation']
    for scope in ('baseline', 'all'):
        for verdict, values in [('TP', tp), ('FP', fp), ('FN', fn)]:
            lines += [','.join((scope, verdict, a, e, r)) for a, e, r in sorted(values)]
    data['score/link_errors.csv'] = ('\n'.join(lines) + '\n').encode()
    if int(version) >= 48:
        data['score/SCORE_RECEIPT.json'] = encoded({
            'status': 'V' + version + '_SCORE_COMMITTED',
            'run_report_sha256': receipt['run_report_sha256'], 'core_sha256': receipt['code_tree_sha256'],
            'frozen_manifest_sha256': prep['frozen_manifest_sha256'],
            'metrics_sha256': digest(data['score/metrics.json']),
            'link_errors_sha256': digest(data['score/link_errors.csv'])})
    reseal(data, run_id)
    return data


def reseal(data, run_id=None):
    run_id = run_id or json.loads(data['RUN_RECEIPT.json'])['run_id']
    data['DIAGNOSTIC_BUNDLE_MANIFEST.json'] = encoded({
        'run_id': run_id, 'member_sha256': {k: digest(v) for k, v in data.items()
                                         if k != 'DIAGNOSTIC_BUNDLE_MANIFEST.json'}})


class AuditTests(unittest.TestCase):
    def test_roundtrip_and_read_only(self):
        data = fixture()
        original = deepcopy(data)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'source.zip'
            with zipfile.ZipFile(path, 'w') as archive:
                for name, raw in data.items():
                    archive.writestr(name, raw)
            before = path.read_bytes()
            result = validate_snapshot(read_zip(path))
            self.assertEqual(result['metrics']['results']['all']['tp'], 1)
            self.assertEqual(before, path.read_bytes())
        self.assertEqual(original, data)

    def test_equal_tp_counts_still_report_swaps_and_regression(self):
        a = ('artifact-one', 'target-one', 'supports')
        b = ('artifact-two', 'target-two', 'supersedes')
        extra = ('artifact-three', 'target-three', 'supports')
        reference = validate_snapshot(fixture(tp={a}, fn={b}))
        candidate = validate_snapshot(fixture('48', tp={b}, fp={extra}, fn={a}))
        result = compare(reference, candidate)
        self.assertEqual(result['quality_gate'], 'REGRESSION_ON_THIS_RUN')
        self.assertEqual(len(result['true_positive_gained']), 1)
        self.assertEqual(len(result['true_positive_lost']), 1)
        self.assertEqual(len(result['false_positive_added']), 1)

    def test_model_change_stays_explicit(self):
        reference = validate_snapshot(fixture())
        candidate = deepcopy(reference)
        candidate['receipt']['model'] = {'judge': 'changed'}
        self.assertFalse(compare(reference, candidate)['same_model_ids'])

    def test_different_inputs_or_references_block_comparison(self):
        reference = validate_snapshot(fixture())
        for field in ['runtime_s0_sha256', 'history_sha256', 'frozen_s0_sha256', 'frozen_manifest_sha256']:
            with self.subTest(field=field):
                candidate = deepcopy(reference)
                candidate['prep'][field] = 'changed'
                with self.assertRaisesRegex(ValueError, 'Incomparable'):
                    compare(reference, candidate)

    def test_changed_exact_reference_set_blocked(self):
        reference = validate_snapshot(fixture())
        candidate = validate_snapshot(fixture('48', fn={('different', 'target-two', 'supersedes')}))
        with self.assertRaisesRegex(ValueError, 'expected exact triples changed'):
            compare(reference, candidate)

    def test_tampered_member_is_rejected(self):
        data = fixture()
        data['run/report.json'] += b' '
        with self.assertRaisesRegex(ValueError, 'Bundle hash mismatch'):
            validate_snapshot(data)

    def test_resealed_tamper_still_fails_receipt(self):
        data = fixture()
        data['run/report.json'] += b' '
        reseal(data)
        with self.assertRaisesRegex(ValueError, 'Receipt hash mismatch'):
            validate_snapshot(data)

    def test_wrong_scoring_counts_are_rejected(self):
        data = fixture()
        metrics = json.loads(data['score/metrics.json'])
        metrics['results']['all']['fp'] = 100
        data['score/metrics.json'] = encoded(metrics)
        reseal(data)
        with self.assertRaisesRegex(ValueError, 'Metrics counts differ'):
            validate_snapshot(data)

    def test_prediction_csv_disagreement_is_rejected(self):
        data = fixture(fp={('artifact-three', 'target-three', 'supports')})
        data['score/link_errors.csv'] = data['score/link_errors.csv'].replace(b'artifact-three', b'fake-artifact')
        reseal(data)
        with self.assertRaisesRegex(ValueError, 'Scored predictions differ'):
            validate_snapshot(data)

    def test_invalid_score_denominator_is_rejected(self):
        data = fixture()
        metrics = json.loads(data['score/metrics.json'])
        metrics['results']['all']['gold_positive_exact_triples'] = 99
        data['score/metrics.json'] = encoded(metrics)
        reseal(data)
        with self.assertRaisesRegex(ValueError, 'denominators differ'):
            validate_snapshot(data)

    def test_checkpoint_state_changed_even_with_resealed_receipt_is_rejected(self):
        data = fixture()
        receipt = json.loads(data['RUN_RECEIPT.json'])
        name = receipt['checkpoint_relative_path']
        checkpoint = json.loads(data[name])
        checkpoint['initial_state'] = {'target': 'changed'}
        data[name] = encoded(checkpoint)
        receipt['checkpoint_sha256'] = digest(data[name])
        data['RUN_RECEIPT.json'] = encoded(receipt)
        reseal(data)
        with self.assertRaisesRegex(ValueError, 'initial state differs'):
            validate_snapshot(data)

    def test_duplicate_score_row_is_rejected(self):
        data = fixture()
        data['score/link_errors.csv'] += b'all,TP,artifact-one,target-one,supports\n'
        reseal(data)
        with self.assertRaisesRegex(ValueError, 'Duplicate exact-triple'):
            validate_snapshot(data)

    def test_unsafe_checkpoint_path_is_rejected(self):
        data = fixture()
        receipt = json.loads(data['RUN_RECEIPT.json'])
        receipt['run_id'] = '../escape'
        data['RUN_RECEIPT.json'] = encoded(receipt)
        reseal(data)
        with self.assertRaisesRegex(ValueError, 'Unsafe run ID'):
            validate_snapshot(data)

    def test_unsafe_and_duplicate_zip_members_are_rejected(self):
        for names in [['../escape.json'], ['C:/escape.json'], ['file.json', 'file.json'], ['dir\\file.json']]:
            with self.subTest(names=names), tempfile.TemporaryDirectory() as folder:
                path = Path(folder)/'unsafe.zip'
                with zipfile.ZipFile(path, 'w') as archive:
                    for name in names:
                        archive.writestr(name, '{}')
                with self.assertRaisesRegex(ValueError, 'unsafe or unsupported'):
                    read_zip(path)

    def test_cli_refuses_existing_output_and_preserves_all_files(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder)/'source.zip'
            with zipfile.ZipFile(source, 'w') as archive:
                for name, raw in fixture().items():
                    archive.writestr(name, raw)
            output = Path(folder)/'existing.json'
            output.write_bytes(b'preserve existing output')
            before = source.read_bytes()
            process = subprocess.run([sys.executable, str(Path(__file__).with_name('compare_diagnostics.py')),
                '--reference', str(source), '--candidate', str(source), '--output', str(output)],
                capture_output=True)
            self.assertNotEqual(process.returncode, 0)
            self.assertEqual(output.read_bytes(), b'preserve existing output')
            self.assertEqual(source.read_bytes(), before)

    def test_inconsistent_score_commit_is_rejected(self):
        data = fixture('48')
        receipt = json.loads(data['RUN_RECEIPT.json'])
        data['score/SCORE_RECEIPT.json'] = encoded({
            'status': 'V48_SCORE_COMMITTED', 'run_report_sha256': receipt['run_report_sha256'],
            'core_sha256': receipt['code_tree_sha256'], 'frozen_manifest_sha256': 'fixed-gold-manifest',
            'metrics_sha256': digest(data['score/metrics.json']), 'link_errors_sha256': 'wrong-hash'})
        reseal(data)
        with self.assertRaisesRegex(ValueError, 'Committed score receipt mismatch'):
            validate_snapshot(data)

    def test_missing_v48_score_commit_is_rejected(self):
        data = fixture('48')
        del data['score/SCORE_RECEIPT.json']
        reseal(data)
        with self.assertRaisesRegex(ValueError, 'Committed score receipt required'):
            validate_snapshot(data)


if __name__ == '__main__':
    unittest.main()
