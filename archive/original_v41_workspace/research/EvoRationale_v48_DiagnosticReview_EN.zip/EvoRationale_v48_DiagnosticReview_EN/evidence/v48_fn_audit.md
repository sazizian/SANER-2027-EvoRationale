# v4.8 false-negative source audit

Seven desired links are missing. None was emitted in the desired relation and rejected by the source guard. Two v4.6 true positives were omitted by the classifier despite identical source bytes and available same-event adopted contract. This does not demonstrate a deterministic admission defect.

## 04de3dac4669-F01-H01 / I2 / supersedes

The hunk replaces append-only ResizePolicy with qualified mutability. Fixed I2 promises per-resource restart-policy choices, not mutability of existing policy entries. All three versions omit the link with explicit scope reasons. Do not invent an unseen interim restriction or revise S0/Gold to improve scores.

## 079aa5fb9ab1-F01-H02 / I2 / supersedes

The hunk replaces mutable ResizePolicy with append-only updates for newly introduced resource requirements. It neither withdraws per-resource restart-policy choices nor changes what I2 explicitly asserts. All three versions consistently omit it.

## 079aa5fb9ab1-F01-H05 / C2a / supports

The source states an illegal Guaranteed-to-Burstable in-place change requires recreation. That is explicit evidence of enforcing the fixed QoS boundary. v47 emitted qualified supports; v46/v48 instead selected the mixed-replica recreation cost as weakens, then rejected that wrong-direction candidate because material_target_delta=false. No desired supports candidate was rejected. A generic boundary-versus-cost distinction is worth isolated investigation, but prior broad prompt changes regressed many other links.

## 68952e4476e4-F01-H01 / R2 / supports

The new metric explicitly counts at Pod level, omits InProgress and provides no per-container/per-resource explanation or required Pod Events. The fixed R2 includes those exact qualifications. All three versions omit this relation explicitly; the nearby Resize Status hyperlink alone is not evidence of full R2.

## 964260d9c2da-F01-H03 / I1 / supersedes

The summary removes allocated reporting while retaining actual reporting. v46 accepted mechanism_replacement using local removed/added summary proof plus exact current adopted contract from H04, which establishes local checkpointing and an optional separate alpha allocated-status gate. v48 emits no candidate and says deletion alone is insufficient, without using that available same-event contract. This is a classifier/context-use difference, not a rejected desired effect or evidence that the routing hook failed. Pure-deletion retirement evidence remains allowed by the unchanged v46 instructions.

## 964260d9c2da-F01-H05 / I1 / supersedes

The compatibility warning changes its documented status representation from AllocatedResources allocation to Resources actual configuration. v46 accepted mechanism_replacement using exact current H04 adopted API contract. v48 emits no candidate, treating the warning as incomplete R1/I1 evidence and requiring consumer dependency migration although v46 had classified direct_delta, not dependent_migration. No desired candidate reached the guard; changing an admission guard cannot recover this omission.

## 964260d9c2da-F01-H14 / I1 / weakens

The added Allocated Resources alternatives list API migration, release timing, type consistency and checkpointing costs. The fixed relation asks for reduced justification of its chosen reporting mechanism, but source attribution of candidate costs to that selected mechanism is not unambiguous. v46 emitted conditional I1 supports with current_claim_entailed=false (rejected); v47 abstained; v48 emitted Option-1 I1 supports with current_claim_entailed=true (accepted FP). No desired weakens was emitted. Do not force all alternative costs to weaken a fixed decision.

## Evaluation implication

No deterministic FN-side admission defect is demonstrated. Preserve v46 as strongest measured checkpoint; avoid speculative broad prompt churn. Investigate model consistency separately from source qualification and fixed-target/reference scope tension. If a future semantic change is developed, isolate it, replay unchanged guard outcomes, use generic counterexamples, and measure hosted accuracy independently; unit replay cannot claim improved F1.

The v48 H04/I1 gained TP used same-artifact added contract directly in after proof, without SAME_ARTIFACT_ADDED_CONTEXT hook provenance. The hook repair is demonstrated only by controlled replay of stored v46 effects. Neither replay nor changed hosted counts proves which code change caused prediction differences.
