# v4.8 false-positive audit (offline)

All nine FPs pass exact-source/authority/scope consistency checks under the current permissive evidence-trace policy. Their relation disagreements require semantic judgments about freshness, direct target contribution, partial scope, and conditional rationale. A blanket generic filter would collide with measured true positives; no safe source-guard-only correction is established by this audit.

| Artifact | Target | New vs v4.6 | Issue |
|---|---|---|---|
| 079aa5fb9ab1-F01-H03 | C2a | False | semantic freshness / normative-boundary mismatch |
| 079aa5fb9ab1-F01-H04 | C2a | False | implementation mechanism versus exact normative target |
| 68952e4476e4-F01-H01 | I1 | True | consumption of a representation versus establishment of its reporting contract |
| 964260d9c2da-F01-H04 | R1 | False | multilink completeness / evidence freshness policy boundary |
| 964260d9c2da-F01-H06 | R1 | True | rebound representation / fresh support for surviving invariant |
| 964260d9c2da-F01-H07 | I1 | False | dependent replacement boundary / reference scope ambiguity |
| 964260d9c2da-F01-H08 | I3 | True | operation depending on states versus evidence establishing state-model predicate |
| 964260d9c2da-F01-H14 | I1 | True | conditional alternative sketch versus rationale corroborating the chosen contract |
| 964260d9c2da-F01-H14 | R1 | False | argument about type consistency versus justification of semantic distinction |

## 079aa5fb9ab1-F01-H03 / C2a

The cited class/shape definitions largely rename existing terms and reflow the same meaning. The local class-change prohibition also survives unchanged except emphasis. v48 treats these definitions as fresh whole-element support; v46 instead used the new CPU-and-memory Guaranteed condition as qualified partial support. The conservative lexical screen cannot establish whether a renamed term has substantively new target meaning.

Filter risk: Rejecting all terminology changes mechanically can erase genuine changes in modality, definitions or aliases. The substantive added Guaranteed condition elsewhere in this same hunk also makes whole-hunk rejection unsound.

## 079aa5fb9ab1-F01-H04 / C2a

QoS status persistence and kubelet restart recovery preserve a stored classification. The fixed target is a non-goal on changing a Pod QoS class without restart. The model regards preservation as a partial operational witness, while the frozen reference regards this hunk as implementation-only. v46 and v48 agree on this interpretation; v47 omitted it.

Filter risk: A blanket ban on consumer/storage witnesses would remove legitimate new operational support in other cases.

## 68952e4476e4-F01-H01 / I1

The added completion equality compares spec.Resources, status.Allocated and status.Resources. This clearly witnesses the three-way value distinction (R1), but does not itself specify/report the PodStatus contract (I1) or PodSpec mutability. v48 adds qualified I1 partial support because the operation consumes the two status values; v46 emitted only R1 and I3.

Filter risk: The current profile expressly allows new operational witnesses and partial evidence. Restricting all downstream consumption would repeat the broad v47 restriction that removed many true replacement traces.

## 964260d9c2da-F01-H04 / R1

The actual/allocated checkpoint rewrite preserves desired, allocated and actual roles while replacing the I1 allocated-status reporting representation. v46, v47 and v48 all emitted R1 support alongside this change. The reference accepts I1 supersession and omits the independently corroborated R1 relation. Exact-triple reference disagreement is not a provenance defect.

Filter risk: Suppressing all additional relations when a primary supersession exists directly conflicts with the v46 instruction that a primary effect must not suppress independent evidence for other exact elements.

## 964260d9c2da-F01-H06 / R1

The admission procedure separates desired spec requests, local allocations and later actual-resource status updates. The resource distinction itself already existed before; the local change removes allocated status writes and keeps checkpoints. v48 treats the revised adopted procedure as fresh whole-element evidence; v47 gave partial R1 support, and v46 only I1 dependent supersession.

Filter risk: Freshness and whole-target entailment need semantic decisions. A requirement that every target part be changed would incorrectly forbid genuine fresh evidence for established architecture.

## 964260d9c2da-F01-H07 / I1

Restart recovery explicitly migrates allocation reads from Status...AllocatedResources to checkpoint restoration and cites the adopted same-event checkpoint contract. This satisfies the generic dependent_replacement policy used successfully in several accepted reference links. The frozen reference treats this particular restart-recovery consumer as implementation-only. v46 and v48 accept; v47 omitted all such recovery consumers.

Filter risk: A hunk or restart-specific exclusion would overfit labels. A blanket consumer-replacement ban would remove many true positives.

## 964260d9c2da-F01-H08 / I3

The scheduler changes the accounting branch for InProgress from the old allocated-status branch to pessimistic desired/actual maximum. This operates on existing progress labels; it does not introduce the progress state model. v48 labels this a qualified partial operational witness of I3; v46 and v47 explicitly decline I3 support.

Filter risk: The target says model states rather than define them, and the policy permits operational witnesses. Deciding which branch use qualifies cannot be done using a safe literal whitelist.

## 964260d9c2da-F01-H14 / I1

Conditional alternative Option 1 proposes allocated requests/limits in AcceptedResources alongside actual Resources and lists consistency as a benefit. v48 treats this as direct rationale for the allocated/applied status-reporting clause; it explicitly preserves proposal authority and partial scope. v46 instead emitted an Option 3 I1 candidate with current_claim_entailed=false and rejected it. This is different candidate proof plus classifier entailment judgment, not a failing deterministic guard.

Filter risk: Rejecting proposals as adopted support is already enforced; this candidate is discussion-level direct rationale. Blanket rejection of proposal support would also erase the true C1/G2 actor-owned boundary arguments.

## 964260d9c2da-F01-H14 / R1

Option 1 argues for consistent types across separately named desired/allocated/actual fields. v46 and v48 regard this conditional design sketch as direct rationale for the distinction; v47 declines it. The reference expects I1 weakens and includes neither support relation. The source condition and candidate-specific costs are explicit; assigning a normative relation remains semantic.

Filter risk: A proposal authority or modality guard cannot determine whether the explicit rationale actually supports this exact requirement.

## Generic actionable options

1. Preserve v4.6 and v4.8 snapshots; use this measured development result without claiming a new version improves accuracy.
2. Make the criterion explicit before further tuning: current evidence trace versus exact direct target change. Measure these as distinct diagnostics while keeping the frozen exact-triple score unchanged.
3. Add an offline report for candidate proof/authority/partial scope and prior-run link swaps so failures are reviewable without another API call.
4. If developing a semantic policy, test case-neutral synthetic contrasts for consumer use versus reporting contract, preserved definition versus changed predicate, and conditional alternative consistency versus chosen-mechanism argument; validate on independent held-out decisions before spending on repeated development pilots.
5. A semantic adjudication second phase or multiple independent classifications might reduce interpretation variability, but adds cost/latency and is unproven here. No hosted rerun is needed to establish current provenance or error identities.

Full raw assessment/quote evidence is in v48_fp_audit.json. No runtime, historical score, S0 or gold file was changed.

Broad-filter collateral, measured from the completed v4.8 links:

| Rejected class | FP removed | TP lost |
|---|---:|---:|
| operational_witness | 3 | 2 |
| proposal_or_alternative support | 2 | 2 |
| dependent_replacement | 1 | 5 |
| material_subclaim | 6 | 9 |
