# Independent v4.8 architecture and evaluation review

Recommendation: preserve v4.6 as the strongest **measured descriptive development baseline** and do not promote another prediction version now. Deliver a reproducible, offline provenance and exact-link comparison audit. This does not assert that v4.6 is universally better, that the observed difference is statistically significant, or that its semantics are correct for every reference label.

## What the completed evidence establishes

The v4.8 run completed six classifier requests and six responses without a retry or technical verification failure. It read/classified the same 30 captured diff artifacts as v4.6, within its six-round and input-token limits. The stopped status is `event_round_limit`; `AWAITING_HUMAN_REVIEW`, `REVALIDATE`, and `UNRESOLVED` are investigation/report states, not an API crash. Several required fixed-S0 needs remain unresolved even when all captured diffs are reviewed.

All-scope v4.6 scores are TP=12, FP=7, FN=7, F1=0.631579. v4.8 scores are TP=12, FP=9, FN=7, F1=0.600000. Baseline F1 is 0.689655 versus 0.645161. Exact prediction membership changed: ten previous all-scope TPs survive, two were gained and two lost; five FPs survive, four are new, and two were removed. Equal TP/FN counts do not mean identical correct/missed links.

The inherited `evorationale/evidence_trace_verification.py` files in v4.6 and v4.8 have the same SHA256 (`38165acf8989f1cdd21b6fbeef5c2a01eed61b0bab7f1c4d385873e371f0df8f`). v4.8 changes the bounded initial output allowance and adds a narrow same-artifact current-proof routing hook. Nominal input/query/read/round ceilings and opaque model IDs are equal; request sizes, retry behavior and actual token usage differ. Immutable provider snapshots are not verified. A single completed run per condition cannot separate semantic effects, sampling variation, output allowances or provider variation.

Notably, **none of the 21 accepted v4.8 assessments has `replacement_current_proof_origin=SAME_ARTIFACT_ADDED_CONTEXT`**. The recovered `964260d9c2da-F01-H04 / I1 / supersedes` assessment supplies the checkpoint/optional-alpha current contract directly in its `after_line_handles` and has no context lines. It therefore did not need the repair hook in this hosted run. The stored-v4.6 replay demonstrates that the hook fixes that old response's proof-routing rejection, but the current run cannot attribute the recovered TP to the hook: the model selected different proof lines.

## What source gates prove and what remains semantic

The deterministic layer validates canonical source identity, hashes, time, exact passage/line ownership, diff-side roles, target text anchoring, response shape and bounded request accounting. It also screens formatting-only proof and mechanically inconsistent assessment flags. It deliberately does not prove entailment, authority, materiality or causal dependence; these are marked `MODEL_ASSESSED`.

Most current errors are disagreements about those semantic assessments. Examples include current-use corroboration versus implementation-only bookkeeping, consumer migration versus supersession of a reporting contract, and conditional alternative rationale versus adopted fulfillment. No neutral mechanical filter can decide these from a correct source hash. The earlier v4.7 broad restriction on downstream consumers removed many correct references as well as some false positives. Reintroducing it would repeat an observed failure mode.

Two persistent I2 reference relations concern interim policy restrictions not asserted by the fixed I2 sentence. R2 includes per-resource/per-container explanation and Events, which an aggregate metric does not independently establish. These source/reference tensions should be explicitly reviewed without modifying the fixed state, frozen reference, or exact-triple scorer after inspecting scores. The present audit must distinguish reference disagreement from a verified implementation defect.

No current hosted evidence here justifies changing target text, reference labels, relation mapping or case-specific acceptance rules. A large passing test suite validates the tested invariants; it is not a classifier-accuracy guarantee.

## Coverage limitation confirmed from the schema

`delta_verification._schema` requires the complete S0 ID list only once in top-level `considered_element_ids`, plus one row per artifact. Each artifact row has a general reason and any emitted positive/negative links; it has no required per-target outcome or per-target reason. `_validated_reviews` validates the global target set and artifact count, and accepts an artifact with `links=[]` and one general reason. `review_event` then copies `list(elems)` into each artifact's stored review record.

A local, provider-free schema demonstration using the actual 18-target S0 accepted a generic one-artifact no-relation review containing zero explicit target-pair outcomes. Thus the record's global consideration declaration is self-reported completeness, not mechanical evidence that every artifact-target pair was independently examined. An omitted positive may be abstention, scope disagreement, overshadowing or a missed target. Those cases cannot reliably be separated from the current stored response.

The existing report says review coverage is self-reported, so this is an instrumentation limitation rather than a hidden correctness certification bug. Do not retrospectively reinterpret the stored per-artifact ID copies as 18 independently documented judgments.

## Concrete next action

1. Keep the frozen v4.6/v4.7/v4.8 code and run directories intact. State that v4.6 is the strongest observed run on this development fixture; v4.8 has useful workflow/proof-routing changes but did not improve this measured result.
2. Deliver a standard-library offline audit that validates the supplied diagnostic bundle provenance, reconstructs exact TP/FP/FN triples, compares set membership, checks the scoring denominator and input identity, and reports actual provider request/token accounting. Include the exact gains/losses and the repair-hook-use finding.
3. Use descriptive pass/fail selection language such as “does not beat the recorded baseline under the chosen metric on this run.” Never label the F1 difference statistically significant, causally explained by one patch, or generalizable to unseen projects.
4. Consider a future opt-in classifier profile with one explicit outcome per artifact-target pair (`relation`, `no_relation`, `insufficient_evidence`) and a short source-grounded reason. Validate pair cardinality/duplicates mechanically, keep positive proof rules, and preserve historical profiles. Full reasoning coverage remains model-assessed even then.
5. Evaluate that future profile with predeclared inputs and criteria, independent held-out cases, meaningful robustness checks (similar nouns with different obligations, conditional alternatives, dependent migrations, compound targets), and a controlled run/accounting plan. Changing output shape increases tokens and may require artifact/target batching; measure this rather than promising better accuracy or speed. Do not launch speculative paid repetitions merely to inspect the existing diagnostic archive.

## Review scope

Read-only inspection of frozen v4.8 classifier/gates, actual v4.8 checkpoint/report, v4.6/v4.7 run results, and target coverage schema. No model call, API access, reference mutation or frozen-root edit was made. Internal review file only.
