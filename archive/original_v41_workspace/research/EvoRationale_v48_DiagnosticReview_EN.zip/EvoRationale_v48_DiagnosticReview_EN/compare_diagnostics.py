#!/usr/bin/env python3
"""Compare completed scored diagnostic ZIPs without credentials or model calls.

This is post-run development analysis. It does not modify runtime/scorer code,
certify semantics, estimate statistical significance, or measure held-out quality.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

RELATIONS = {'supports', 'weakens', 'supersedes', 'contradicts'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_zip(path):
    """Read bounded members in memory; never extract archive paths."""
    data = {}
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        if len(members) > 256 or sum(m.file_size for m in members) > 128 * 1024**2:
            raise ValueError('Diagnostic ZIP exceeds supported size limits')
        for member in members:
            name = member.filename
            p = PurePosixPath(name)
            if (name in data or name != p.as_posix() or p.is_absolute()
                    or '..' in p.parts or '\\' in name or ':' in name
                    or member.is_dir() or stat.S_ISLNK(member.external_attr >> 16)
                    or member.file_size > 64 * 1024**2):
                raise ValueError('Duplicate, unsafe or unsupported ZIP member: ' + name)
            data[name] = archive.read(member)  # also validates CRC
    return data


def validate_snapshot(data):
    def document(name, expected=None):
        raw = data[name]
        if expected is not None and digest(raw) != expected:
            raise ValueError('Receipt hash mismatch: ' + name)
        value = json.loads(raw.decode('utf-8-sig'))
        if not isinstance(value, dict):
            raise ValueError('Expected JSON object: ' + name)
        return value

    bundle = document('DIAGNOSTIC_BUNDLE_MANIFEST.json')
    hashes = bundle['member_sha256']
    if not isinstance(hashes, dict) or set(data) != set(hashes) | {'DIAGNOSTIC_BUNDLE_MANIFEST.json'}:
        raise ValueError('Bundle members differ from its manifest')
    for name, expected in hashes.items():
        if digest(data[name]) != expected:
            raise ValueError('Bundle hash mismatch: ' + name)
    receipt = document('RUN_RECEIPT.json')
    matched = re.fullmatch(r'V(\d+)_DEV_HOSTED_RUN_COMPLETED_AND_HASHED', receipt.get('status', ''))
    if not matched or receipt.get('mode') != 'api':
        raise ValueError('Expected a completed hosted development receipt')
    version = matched.group(1)
    run_id = receipt['run_id']
    if not isinstance(run_id, str) or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,127}', run_id) is None:
        raise ValueError('Unsafe run ID')
    if bundle.get('run_id') != run_id:
        raise ValueError('Bundle/run ID mismatch')
    prep = document('DEV_PREP_MANIFEST.json', receipt['prep_sha256'])
    report = document('run/report.json', receipt['run_report_sha256'])
    manifest = document('run/manifest.json', receipt['run_manifest_sha256'])
    checkpoint_path = 'checkpoints/' + run_id + '.json'
    if receipt['checkpoint_relative_path'] != checkpoint_path:
        raise ValueError('Checkpoint receipt path mismatch')
    checkpoint = document(checkpoint_path, receipt['checkpoint_sha256'])
    if checkpoint.get('run_id') != run_id or checkpoint.get('report') != report:
        raise ValueError('Checkpoint/report mismatch')
    for role, filename in [('runtime_s0', 'S0_RETROSPECTIVE_RUNTIME.json'),
                           ('history', 'POST_S0_EVIDENCE_RETROSPECTIVE_53.jsonl')]:
        if digest(data['inputs/' + filename]) != prep[role + '_sha256']:
            raise ValueError('Input hash mismatch: ' + role)
    if checkpoint.get('initial_state') != document('inputs/S0_RETROSPECTIVE_RUNTIME.json'):
        raise ValueError('Checkpoint initial state differs from fixed runtime input')
    if (checkpoint.get('verified_links') != report.get('verified_evidence')
            or report.get('investigation_profile') != receipt['investigation_profile']):
        raise ValueError('Checkpoint links/report profile mismatch')
    expected_manifest = {'run_id': run_id, 'mode': 'api',
                         'investigation_profile': receipt['investigation_profile'],
                         'report_sha256': receipt['run_report_sha256'],
                         'decision_sha256': prep['runtime_s0_sha256'],
                         'history_sha256': prep['history_sha256']}
    if any(manifest.get(k) != v for k, v in expected_manifest.items()):
        raise ValueError('Run manifest provenance mismatch')
    if (receipt['code_tree_sha256'] != prep['v' + version + '_python_sha256']
            or receipt['model'] != prep['models'] or receipt['nominal_budgets'] != prep['budgets']
            or receipt['investigation_profile'] != prep['investigation_profile']):
        raise ValueError('Preparation/receipt provenance mismatch')
    metrics = document('score/metrics.json')
    if (metrics.get('status') != 'V' + version + '_DEVELOPMENT_ONLY_POST_RUN_REFERENCE_COMPARISON'
            or metrics.get('v' + version + '_run_report_sha256') != receipt['run_report_sha256']
            or metrics.get('v' + version + '_code_sha256') != receipt['code_tree_sha256']
            or metrics.get('frozen_s0_sha256') != prep['frozen_s0_sha256']
            or metrics.get('investigation_profile') != receipt['investigation_profile']
            or metrics.get('models') != receipt['model']
            or metrics.get('nominal_budgets') != receipt['nominal_budgets']
            or metrics.get('budget_usage') != report['budget_usage']
            or metrics.get('verified_evidence_links') != len(report['verified_evidence'])):
        raise ValueError('Score provenance mismatch')
    if int(version) >= 48 and 'score/SCORE_RECEIPT.json' not in data:
        raise ValueError('Committed score receipt required for v4.8 and later')
    if 'score/SCORE_RECEIPT.json' in data:
        committed = document('score/SCORE_RECEIPT.json')
        expected_commit = {'status': 'V' + version + '_SCORE_COMMITTED',
                           'run_report_sha256': receipt['run_report_sha256'],
                           'core_sha256': receipt['code_tree_sha256'],
                           'frozen_manifest_sha256': prep['frozen_manifest_sha256'],
                           'metrics_sha256': digest(data['score/metrics.json']),
                           'link_errors_sha256': digest(data['score/link_errors.csv'])}
        if any(committed.get(k) != v for k, v in expected_commit.items()):
            raise ValueError('Committed score receipt mismatch')
    rows = list(csv.DictReader(io.StringIO(data['score/link_errors.csv'].decode('utf-8-sig'))))
    sets = {s: {v: set() for v in ('TP', 'FP', 'FN')} for s in ('baseline', 'all')}
    for row in rows:
        key = (row['hunk_id'], row['atomic_s0_id'], row['relation'])
        if row['relation'] not in RELATIONS or row['scope'] not in sets or row['verdict'] not in sets[row['scope']]:
            raise ValueError('Unexpected exact-triple score row')
        dest = sets[row['scope']][row['verdict']]
        if key in dest:
            raise ValueError('Duplicate exact-triple score row')
        dest.add(key)
    for scope, values in sets.items():
        if any(values[a] & values[b] for a, b in [('TP', 'FP'), ('TP', 'FN'), ('FP', 'FN')]):
            raise ValueError('Conflicting exact-triple score verdicts')
        tp, fp, fn = (len(values[v]) for v in ('TP', 'FP', 'FN'))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else None
        f1 = 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0
        actual = metrics['results'][scope]
        if any(actual[k] != value for k, value in [('tp', tp), ('fp', fp), ('fn', fn)]):
            raise ValueError('Metrics counts differ from exact-triple rows')
        if (actual.get('predicted_exact_triples') != tp + fp
                or actual.get('gold_positive_exact_triples') != tp + fn):
            raise ValueError('Metrics denominators differ from exact-triple rows')
        for k, value in [('precision', precision), ('recall', recall), ('f1', f1)]:
            if value is None:
                if actual[k] is not None:
                    raise ValueError('Metrics recall differs from exact-triple rows')
            elif not isinstance(actual[k], (float, int)) or not math.isfinite(actual[k]) or abs(actual[k] - value) > 0.000001:
                raise ValueError('Metrics rate differs from exact-triple rows: ' + k)
    if any(not sets['baseline'][v].issubset(sets['all'][v]) for v in ('TP', 'FP', 'FN')):
        raise ValueError('Baseline verdicts disagree with all-scope verdicts')
    if metrics['results']['all'].get('unscored_prediction_links_outside_hunk_universe') != 0:
        raise ValueError('This audit supports fully scored diagnostic predictions only')
    report_set = {(l['artifact_id'], l['decision_element_id'], l['relation'])
                  for l in report['verified_evidence']}
    if report_set != sets['all']['TP'] | sets['all']['FP']:
        raise ValueError('Scored predictions differ from completed report')
    return {'version': 'v' + version, 'receipt': receipt, 'prep': prep,
            'report': report, 'checkpoint': checkpoint, 'metrics': metrics, 'sets': sets}


def triples(values):
    return [{'artifact_id': a, 'element_id': e, 'relation': r} for a, e, r in sorted(values)]


def compare(reference, candidate, scope='all'):
    for field in ['runtime_s0_sha256', 'history_sha256', 'frozen_s0_sha256', 'frozen_manifest_sha256']:
        if reference['prep'][field] != candidate['prep'][field]:
            raise ValueError('Incomparable source/reference provenance: ' + field)
    for s in ('baseline', 'all'):
        x, y = reference['sets'][s], candidate['sets'][s]
        if x['TP'] | x['FN'] != y['TP'] | y['FN']:
            raise ValueError('Scored expected exact triples changed: ' + s)
    x, y = reference['sets'][scope], candidate['sets'][scope]
    rm, cm = reference['metrics']['results'][scope], candidate['metrics']['results'][scope]
    rb, cb = reference['report']['budget_usage'], candidate['report']['budget_usage']
    # Compare exact count-based F1 before rounding display values.
    xd = max(1, 2 * len(x['TP']) + len(x['FP']) + len(x['FN']))
    yd = max(1, 2 * len(y['TP']) + len(y['FP']) + len(y['FN']))
    signed = 2 * len(y['TP']) * xd - 2 * len(x['TP']) * yd
    delta = signed / (xd * yd)
    return {'status': 'OFFLINE_POST_RUN_DESCRIPTIVE_COMPARISON_NO_API', 'scope': scope,
            'reference_version': reference['version'], 'candidate_version': candidate['version'],
            'reference_run_id': reference['receipt']['run_id'], 'candidate_run_id': candidate['receipt']['run_id'],
            'reference_metrics': rm, 'candidate_metrics': cm, 'f1_delta': round(delta, 6),
            'quality_gate': 'REGRESSION_ON_THIS_RUN' if signed < 0 else
                            'IMPROVEMENT_ON_THIS_RUN' if signed > 0 else 'TIED_ON_THIS_RUN',
            'same_model_ids': reference['receipt']['model'] == candidate['receipt']['model'],
            'same_nominal_budgets': reference['receipt']['nominal_budgets'] == candidate['receipt']['nominal_budgets'],
            'true_positive_retained': triples(x['TP'] & y['TP']),
            'true_positive_gained': triples(y['TP'] - x['TP']),
            'true_positive_lost': triples(x['TP'] - y['TP']),
            'false_positive_retained': triples(x['FP'] & y['FP']),
            'false_positive_added': triples(y['FP'] - x['FP']),
            'false_positive_removed': triples(x['FP'] - y['FP']),
            'false_negative_remaining': triples(y['FN']),
            'resource_usage': {name: {k: budget.get(k) for k in
                ['estimated_input_tokens', 'provider_reported_input_tokens', 'provider_reported_output_tokens',
                 'provider_requests_reserved', 'provider_responses_received', 'unique_artifact_reads']}
                for name, budget in [('reference', rb), ('candidate', cb)]},
            'limitations': ['Hashes establish internal consistency, not signed authenticity or semantic correctness.',
                'The gate describes this pair of development runs; it is not statistical significance.',
                'Policy/output allowance and actual provider usage can differ despite equal nominal budgets.',
                'Opaque matching model IDs do not certify matching immutable provider snapshots.',
                'No reference labels are sent to a model; no input/run/score is changed.',
                'Repeated tuning on this pilot does not establish held-out generalization.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference', required=True, type=Path, help='Completed diagnostic ZIP')
    parser.add_argument('--candidate', required=True, type=Path, help='Completed diagnostic ZIP')
    parser.add_argument('--scope', choices=['baseline', 'all'], default='all')
    parser.add_argument('--output', required=True, type=Path, help='New comparison JSON; never overwritten')
    args = parser.parse_args()
    result = compare(validate_snapshot(read_zip(args.reference)), validate_snapshot(read_zip(args.candidate)), args.scope)
    # Exclusive creation only after both immutable input snapshots are validated.
    with args.output.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ['status', 'reference_version', 'candidate_version', 'scope',
                                           'quality_gate', 'f1_delta']}, indent=2))


if __name__ == '__main__':
    main()
