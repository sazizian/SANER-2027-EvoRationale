EvoRationale v4.8 diagnosis and tested offline comparison
=======================================================

Double-click REPORT_V48_REVIEW.html for the short review.
Read REPORT_V48_REVIEW.md for the complete evidence and evaluation plan. Results are already computed.
No API key, virtual environment activation or new hosted run is needed.

Decision: keep v4.6 as the best measured development baseline.
Preserve v4.6/v4.7/v4.8 code and completed run/score directories.
This package is a diagnosis/audit tool, not a v4.9 prediction release.

All-scope F1: v4.6=0.631579, v4.7=0.333333, v4.8=0.600000.
The full FP/FN source audits are in evidence/.
Exact link changes are in v46_vs_v48_all.json and baseline.json.
Independent architecture review explains the next controlled evaluation.

OPTIONAL: recompute the comparison locally in PowerShell
After extracting this ZIP, open PowerShell in the extracted folder.
Paste these commands without the PS prompt or >> characters:

$py = Join-Path $env:LOCALAPPDATA "er4venv\Scripts\python.exe"
$referenceZip = Join-Path $env:LOCALAPPDATA "ER1287Eval_v46Dev01\EvoRationale_v46_Diagnostics_20261011-155343-966.zip"
$candidateZip = Join-Path $env:LOCALAPPDATA "ER1287Eval_v48Dev01\EvoRationale_v48_Diagnostics_20261011-181147-645.zip"

if (-not (Test-Path -LiteralPath $referenceZip -PathType Leaf)) {
    $referenceZip = (Read-Host "Paste the full path to the v4.6 diagnostic ZIP").Trim().Trim('"')
}
if (-not (Test-Path -LiteralPath $candidateZip -PathType Leaf)) {
    $candidateZip = (Read-Host "Paste the full path to the v4.8 diagnostic ZIP").Trim().Trim('"')
}

$output = Join-Path (Get-Location).Path ("comparison_" + (Get-Date -Format "yyyyMMdd-HHmmss-fff") + ".json")
& $py ".\compare_diagnostics.py" --reference "$referenceZip" --candidate "$candidateZip" --scope all --output "$output"
if ($LASTEXITCODE -ne 0) { throw "Comparison failed. Send the complete error." }
Get-Content -LiteralPath $output -Raw -Encoding UTF8

Optional audit tests, from this same extracted folder:
& $py -m unittest -v test_compare_diagnostics

The comparison output is created exclusively. Existing output is preserved.
Runtime source, inputs, S0, frozen labels, runs and scores are never changed.
No network or model request is performed. Diagnostic ZIPs are read in memory.
