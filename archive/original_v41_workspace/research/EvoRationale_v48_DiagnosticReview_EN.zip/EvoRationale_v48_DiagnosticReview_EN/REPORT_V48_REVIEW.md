# EvoRationale v4.8: completed-run diagnosis

**Recommendation: retain v4.6 as the strongest measured development baseline. Preserve all existing versions and completed runs.** v4.8 completed successfully, but it did not improve exact-triple accuracy on this fixture. This package adds a tested offline comparison tool and an evidence-based review; it is not a new prediction release.

## Measured results

| Version | Baseline TP/FP/FN | Baseline F1 | All TP/FP/FN | All F1 |
|---|---|---:|---|---:|
| v4.6 | 10 / 5 / 4 | 0.689655 | 12 / 7 / 7 | 0.631579 |
| v4.7 | 2 / 6 / 12 | 0.181818 | 5 / 6 / 14 | 0.333333 |
| v4.8 | 10 / 7 / 4 | 0.645161 | 12 / 9 / 7 | 0.600000 |

For v4.8 versus v4.6, all-scope F1 decreased by 0.031579 and baseline F1 decreased by 0.044494. v4.8 retained 10 earlier correct triples, gained two and lost two. Equal TP/FN counts do not mean identical relations.

| Changed correct triple | Artifact | Target | Relation |
|---|---|---|---|
| Gained | 964260d9c2da-F01-H04 | I1 | supersedes |
| Gained | 964260d9c2da-F01-H13 | R1 | supports |
| Lost | 964260d9c2da-F01-H03 | I1 | supersedes |
| Lost | 964260d9c2da-F01-H05 | I1 | supersedes |

Four false positives were added and two earlier false positives removed. The JSON comparisons contain every exact membership change in both scopes, using the unchanged scorer's existing results.

## What failed

The problem is semantic classification consistency. Source retrieval, source identities, quoted lines, local budgets and completed-run provenance passed the checks. v4.8 reviewed all 30 captured diff artifacts in six event batches, with six provider responses, no retry and no technical verification failure. Its two rejected interpretations were different from the seven desired missing triples. **None of the seven missed reference triples was proposed in its desired relation and then rejected by the guard.**

The lost H03/H05 relations illustrate the inconsistency. v4.6 used the exact same-event adopted checkpoint/optional-alpha contract in H04 to interpret the local reporting change as I1 supersession. v4.8 omitted these relations and treated the local deletion or warning rewording as insufficient. The unchanged instructions already permit affirmative same-event replacement/retirement evidence. A guard change cannot recover a relation the classifier does not emit.

The new false positives interpret status consumption as establishing a reporting contract, admission rewording as fresh support for an existing distinction, scheduler state use as support for its state model, and a conditional alternative sketch as supporting rationale. The current evidence-trace policy admits operational witnesses, partial scopes and qualified discussion-level rationale. These are semantic boundary disagreements, not hash/quotation failures.

Broad restrictions would lose measured correct links:

| Blanket restriction on current accepted links | FP removed | TP lost |
|---|---:|---:|
| All operational witnesses | 3 | 2 |
| All proposal/alternative support | 2 | 2 |
| All dependent replacements | 1 | 5 |
| All partial scopes | 6 | 9 |

The earlier v4.7 regression is direct evidence that a broad restriction can hurt recall severely. No case-neutral deterministic guard repair was demonstrated for the remaining v4.8 errors. This review therefore does not ship another speculative semantic-policy version.

## Reference and target scope disagreements

Two persistent I2 reference relations concern changing an interim ResizePolicy mutability restriction. Fixed I2 states per-resource restart-policy choices; it does not assert that mutability restriction. R2 requires per-container/per-resource explanations plus Events; the cited aggregate Pod metric does not independently establish those qualifications. Other disagreements concern implementation-only consumer migration and which alternative costs actually weaken the selected mechanism.

These remain scored FP/FN under the frozen reference. They are recorded as scope disagreements for independent human review, without editing S0, the frozen reference, historical results or the scorer to improve the measured score. The full nine-FP and seven-FN reviews, with raw assessments and source text, are in `evidence/`.

## What the v4.8 routing repair establishes

The controlled replay of stored v4.6 assessments demonstrated one narrow proof-routing rejection repaired while preserving prior accepted effects. This tested behavior remains useful. However, **zero accepted effects in the actual hosted v4.8 run used `SAME_ARTIFACT_ADDED_CONTEXT` repair provenance**. Its gained H04/I1 relation selected added contract lines directly as after-proof and did not invoke that rescue hook. The observed gain cannot be causally attributed to the routing patch. Unit replay is not a new accuracy measurement.

## Architecture limitation and next development direction

The response schema requires a global list of the 18 fixed targets and one review per artifact, but no explicit outcome per artifact-target pair. An artifact can return a general explanation and zero links. The runtime copies the target ID list into its review record; this remains self-reported coverage, not 18 separately documented judgments. Thus the current diagnostics cannot reliably distinguish deliberate abstention from a missed target.

A future opt-in profile should require one outcome per artifact-target pair: relation, no relation, or insufficient evidence, with a short source-grounded reason. The verifier can then enforce pair cardinality and duplicates. Historical profiles and positive proof rules should remain intact. This would improve observability; it has not been shown to improve accuracy. It also increases output volume and may require artifact/target batching.

Evaluate such a profile on independent held-out decisions using predeclared semantic criteria and accounting. Include generic contrasts for consumer use versus reporting contracts, retained predicates versus fresh evidence, normative boundaries versus costs, conditional alternatives, dependent migrations and compound targets. Repeated tuning on this one pilot does not establish generalization. No additional provider call is necessary to inspect the current errors.

## Resource usage

| Recorded resource | v4.6 | v4.8 |
|---|---:|---:|
| Provider requests/responses | 7 / 7 | 6 / 6 |
| Provider input tokens | 45,800 | 38,759 |
| Provider output tokens | 26,646 | 21,026 |
| Estimated input budget charge | 62,911 | 53,495 |
| Unique diff reads | 30 | 30 |
| Receipt elapsed seconds | 440.507 | 341.932 |

v4.8 consumed fewer recorded requests/tokens and finished sooner in this pair of runs, while accuracy declined. These are observed resource measurements, not repeated latency benchmarks or billing estimates. Model IDs and nominal budgets match, but policy/proof routing, output allowances, retry patterns and actual request usage differ; immutable model snapshots are unverified. The F1 difference is descriptive and not a significance claim.

## Tested deliverable

`compare_diagnostics.py` uses Python's standard library and performs no model or network calls. It checks bounded ZIP members, CRCs, bundle/receipt hashes, report/checkpoint/input identity, score provenance, exact score rows, denominators and report predictions. It requires matching S0/history/frozen-reference hashes and matching reconstructed expected triple sets before comparison. It reports gains/losses and a descriptive F1 gate calculated from exact counts before rounding.

Seventeen automated tests passed, including tampered archives, receipt mismatches, changed references, inconsistent counts/denominators, unsafe ZIP/checkpoint paths, score-commit corruption, exact-link swaps with equal TP counts and preservation of existing output. Four comparisons against the actual v4.6/v4.7/v4.8 diagnostic ZIPs reproduced both-scope differences. Source archives were unchanged; frozen v4.6/v4.8 core hashes still match their releases. No API was called during this investigation.

The tool supports completed scored development diagnostic ZIPs using the v4.6-and-later receipt format, with all accepted prediction links scored in the all scope. Unsupported snapshots fail closed. Hashes establish internal consistency, not signed authenticity or semantic correctness. This tool reads post-run reference-derived scores locally; it never supplies them to an agent or modifies prediction results.

v4.8's historical 712 passing runtime tests validate those tested invariants. The 17 new tests validate this offline audit. Neither test count certifies classifier accuracy, architecture-outcome accuracy, production completeness or held-out performance. `AWAITING_HUMAN_REVIEW` / `UNRESOLVED` with `event_round_limit` is the completed investigation state, not an API crash.
