# Review Label Guide

## S0_Review.csv — `reviewer_verdict`

- `ACCEPT`: Meaning and scope are supported by the cited 2023 baseline; independent of whether implementation ultimately succeeded.
- `REWRITE`: Underlying idea appears in the 2023 baseline, but the claim needs clarification, narrower language, decomposition, or corrected terminology. Fill `proposed_correction`.
- `REJECT`: The 2023 pinned text does not support the claim, or the claim inserts a later-only requirement.
- `NEEDS_CONTEXT`: The provided baseline is insufficient; identify what source or context is missing.

For each row enter `exact_quote_or_anchor_to_verify`, `reviewer_reason`, `reviewer_id`, and `review_date_utc`. A brief paraphrase plus precise line range is sufficient; prefer short quotations over copying long passages.

## Timeline_Screening.csv — `screening_decision`

- `POTENTIALLY_RELEVANT`: A candidate for analysis against a documented S0 rationale element, pending full evidence.
- `NOT_RELEVANT`: Clearly unrelated to the documented S0 rationale.
- `NEEDS_DIFF`: Metadata/title suggests a possible relation, but detailed patch was not included.
- `UNCERTAIN`: Neither inclusion nor exclusion can be justified from the supplied material.

Record `possible_s0_element_ids` and `screening_notes`; empty candidate IDs are fine if unrelated.

## Selected_Event_Review.csv and Hunk_Review.csv — relation labels

- `SUPPORTS`: The evidence provides specific support for a 2023 documented rationale element.
- `WEAKENS`: The evidence reduces confidence in a documented rationale, without clearly contradicting it.
- `CONTRADICTS`: The evidence directly conflicts with a documented baseline claim (identify both sides).
- `SUPERSEDES`: A later, documented decision replaces an earlier one; explain whether this is the 2023 baseline or an interim version.
- `IMPLEMENTATION_ONLY`: A technical change with no supported inference about the *reason* for the original decision.
- `UNRELATED`: No relevant link to the cited S0 elements.
- `UNKNOWN`: Evidence or chronology insufficient to assign a defensible relation.

For `reviewer_drift_type`, use a carefully evidenced, concise, English phrase or `UNKNOWN`. There is no obligation to identify drift.

## Temporal basis

- `BASELINE_2023`: The claim compares directly against the pinned 2023 baseline.
- `INTERIM_2024`: The evidence concerns a change in an intermediate 2024 plan or design state without a proven change to 2023 S0.
- `BOTH`: Both comparisons are supported and explicitly explained.
- `UNKNOWN`: The distinction cannot be made with the supplied record.

## A few common mistakes to avoid

- Marking a beta-scope deferral as a permanent rejection of the feature.
- Confusing a documentation update with falsification of its underlying design motivation.
- Counting multiple hunks from the same commit as independent events.
- Using a 2024 discussion or implementation to retroactively expand what the 2023 document said.
- Treating a suggested keyword link as a verified semantic relation.
