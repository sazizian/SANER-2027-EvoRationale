# Source Provenance and Limitations

- Repository: `kubernetes/enhancements`.
- Baseline commit: `5950905de89aab2be202d28b823701276cbefea0`.
- Baseline UTC timestamp: `2023-10-26T15:17:39Z`.
- README SHA-256: `f42855e662d154268b3fca59ef816128f8b7e5359e56466a174a375a930b26fa`.
- `kep.yaml` SHA-256: `a48b0aa683a193ef097604d7404a187a43cc60deb847c67dde702e6a88d32620`.
- README Git blob SHA-1: `ce5124cf7975a7d4ce6a122b2cb4006b4bc0ea2d`.
- YAML Git blob SHA-1: `fd75bc9a121275a09debf7fd55304b483405bd36`.
- Post-baseline window ends exclusively at `2024-10-11T00:00:00Z`.
- Detailed diff files available: 4 of 23 timeline commits. There are 30 indexed patch hunks.
- All source files are copies of the user's captured research archive. Their hashes and source URLs are listed in `sources/SOURCE_INDEX.csv`.

**Important:** This snapshot establishes that specific Git file content is reproducible; it does not establish the first approval date of KEP-1287. The 23-entry timeline is bounded and the four available diffs are selected, not an exhaustive archive. Labels are missing and human adjudication has not occurred. The source capture is retrospective. Time of capture is not the commit date. No paper metrics or gold-standard judgments should be inferred from this packet alone.
