# Reviewer A Return Checklist

- [ ] I reviewed all 12 S0 candidate statements against the **pinned 2023** README and YAML, not a newer version.
- [ ] Each S0 row has a verdict, an anchor or brief quote, a reason, a reviewer ID, and a UTC review date.
- [ ] For any `REWRITE` row, I supplied English replacement wording.
- [ ] I screened 23 listed post-baseline commit records, marking items with missing detailed diffs as `NEEDS_DIFF` or `UNCERTAIN` when appropriate.
- [ ] I reviewed four selected commit diffs and recorded their relations to specific 2023 rationale elements, or `UNKNOWN` / `IMPLEMENTATION_ONLY` as justified.
- [ ] I reviewed the 30 hunk rows against full patch text when necessary and did not treat the previews as complete evidence if truncated.
- [ ] I distinguished 2023 baseline changes from 2024 interim revisions.
- [ ] I completed my review independently, without seeing Reviewer B's results or the model's answers.
- [ ] I did not change source files, commit hashes, candidate IDs, or source URLs.

## Return these edited files

1. `forms/S0_Review.csv`
2. `forms/Timeline_Screening.csv`
3. `forms/Selected_Event_Review.csv`
4. `forms/Hunk_Review.csv`

If parts are unfinished, please identify which ones and the reason. Do not feel pressured to assign a non-`UNKNOWN` verdict when the evidence is insufficient.

## Excel / CSV notes

- Open/edit these as UTF-8 CSVs; preserve exact column headers and identifiers.
- Save as **CSV UTF-8 (Comma delimited)**. If Excel offers to convert IDs, long commit hashes, or timestamps, preserve them as text.
- Do not silently round numeric-looking identifiers or trim hash strings.
- You need not install software or run scripts; source URLs are also provided.
