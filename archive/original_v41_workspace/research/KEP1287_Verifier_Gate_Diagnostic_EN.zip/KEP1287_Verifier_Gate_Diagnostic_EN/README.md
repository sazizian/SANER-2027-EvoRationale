# KEP-1287: Read-Only Verifier Diagnostic

This package inspects an **existing** completed EvoRationale v4.1 API development run. It makes **no API calls**, does not modify any run data, and does not alter the reviewer-confirmed reference.

## PowerShell (from the EvoRationale project root)

Download the ZIP to the project's `research` folder.

```powershell
$env:PYTHONUTF8 = '1'
$py = Join-Path $env:LOCALAPPDATA 'er4venv\Scripts\python.exe'
$toolRoot = Join-Path $env:LOCALAPPDATA 'ER1287DiagTools'
$apiEval = Join-Path $env:LOCALAPPDATA 'ER1287Eval_API01'
$freeze = Join-Path $env:LOCALAPPDATA 'ER1287Gold\KEP1287_Reviewer_Confirmed_Freeze'
$diag = Join-Path $env:LOCALAPPDATA 'ER1287VerifierDiag01'
if (Test-Path $toolRoot) { throw 'Tool path already exists; choose a new unused location.' }
if (Test-Path $diag) { throw 'Diagnostic output exists; choose a new unused location.' }
Expand-Archive -LiteralPath '.\research\KEP1287_Verifier_Gate_Diagnostic_EN.zip' -DestinationPath $toolRoot
& $py "$toolRoot\KEP1287_Verifier_Gate_Diagnostic_EN\audit_existing_run.py" `
  --evaluation "$apiEval" `
  --frozen "$freeze" `
  --code-root '.' `
  --output "$diag"
```

## Outputs

- `diagnostic_summary.json`: complete rejection counts and initial deterministic screen feasibility.
- `rejection_reasons.csv`: exact count by reason category, including `MODEL_ASSESSED` as one category.
- `rejected_interpretations.csv`: read-only index of rejected interpretations. It does not contain LLM quotations because the v4.1 checkpoint stores verification feedback without the raw proposal text.
- `gold_span_screen_probe.csv`: after-run analysis of whether any source span produced by `evidence_spans` can pass the deterministic `direct_relevance` gate for each positive human-reference triple. This is **not** a full end-to-end model recall ceiling.

**Interpretation:** All of these data are development diagnostics, not held-out evaluation. A source fragment passing `direct_relevance` is not thereby semantically correct. A missing pass among the extracted spans does not prove that no alternative exact contiguous quote could be acceptable. Do not change the Gold reference or relax provenance/hash/time/quote checks in response to low scores.
