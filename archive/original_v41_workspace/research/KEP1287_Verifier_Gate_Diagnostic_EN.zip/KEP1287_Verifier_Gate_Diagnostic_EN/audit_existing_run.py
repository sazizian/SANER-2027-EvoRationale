#!/usr/bin/env python3
"""Read-only diagnostic of a completed KEP-1287 EvoRationale API pilot.

No API requests, no scoring changes, and no writes to S0, reference, or agent inputs.
The 'span feasibility' calculation is a lexical-screen probe, NOT a performance
metric, human-label correction, or substitute for semantic adjudication.
"""
from __future__ import annotations
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import sys

POSITIVE = {'SUPPORTS':'supports','WEAKENS':'weakens','SUPERSEDES':'supersedes','CONTRADICTS':'contradicts'}


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1<<20), b''): h.update(chunk)
    return h.hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--evaluation',required=True,type=Path,help='Existing completed API run directory')
    ap.add_argument('--frozen',required=True,type=Path,help='Existing reviewer-confirmed frozen reference')
    ap.add_argument('--code-root',required=True,type=Path,help='Original unmodified EvoRationale v4.1 code root')
    ap.add_argument('--output',required=True,type=Path,help='NEW diagnostics directory; must not already exist')
    args=ap.parse_args()
    ev=args.evaluation.resolve(); frozen=args.frozen.resolve(); code=args.code_root.resolve(); out=args.output.resolve()
    if out.exists():raise FileExistsError(f'Refusing to overwrite existing diagnostics: {out}')
    if not (code/'evorationale'/'evidence_semantics.py').is_file():raise ValueError('Missing EvoRationale package in --code-root')
    prep=load_json(ev/'PREP_MANIFEST.json')
    receipt=load_json(ev/'RUN_RECEIPT.json')
    run_manifest=load_json(ev/'run'/'manifest.json')
    f_manifest=load_json(frozen/'FREEZE_MANIFEST.json')
    if receipt.get('status')!='HOSTED_MODEL_RUN_COMPLETED_AND_HASHED':raise ValueError('API run is not complete')
    if run_manifest.get('run_id')!=receipt.get('run_id'):raise ValueError('Run ID mismatch')
    if run_manifest.get('mode')!='api':raise ValueError('Input is not an API run')
    report=ev/'run'/'report.json'
    if sha256(report)!=run_manifest['report_sha256']:raise ValueError('API report hash mismatch')
    if run_manifest['report_sha256']!=receipt['run_report_sha256']:raise ValueError('API receipt does not match report')
    for p,key in [('S0_RETROSPECTIVE_RUNTIME.json','runtime_s0_sha256'),
                  ('POST_S0_EVIDENCE_RETROSPECTIVE_53.jsonl','history_sha256')]:
        if sha256(ev/'inputs'/p)!=prep[key]:raise ValueError('Pinned input mismatch: '+p)
    hist_path=ev/'inputs'/'POST_S0_EVIDENCE_RETROSPECTIVE_53.jsonl'
    history=[json.loads(line) for line in hist_path.read_text(encoding='utf-8').splitlines() if line.strip()]
    if len(history)!=53:raise ValueError('Expected 53 evidence artifacts')
    ref=frozen/'reference'/'HUNK_RELATIONS_CANDIDATE.csv'
    if sha256(ref)!=f_manifest['reference_sha256'][ref.name]:raise ValueError('Frozen human reference checksum mismatch')
    if sha256(frozen/'S0_ATOMIC_REVIEWER_CONFIRMED.json')!=f_manifest['s0_sha256']:
        raise ValueError('Frozen S0 checksum mismatch')
    checkpoint=ev/'checkpoints'/(receipt['run_id']+'.json')
    memory=load_json(checkpoint)
    # Import the project's own verifier without writing __pycache__ into its source tree.
    sys.dont_write_bytecode = True
    sys.path.insert(0,str(code))
    from evorationale.model import elements
    from evorationale.evidence_semantics import evidence_spans, direct_relevance
    state=load_json(ev/'inputs'/'S0_RETROSPECTIVE_RUNTIME.json')
    element_map={item['id']: item for item in elements(state)}
    artifact_map={a['artifact_id']:a for a in history}
    rejected=memory.get('rejected_interpretations',[])
    reasons=Counter()
    detail=[]
    for i,entry in enumerate(rejected,1):
        raw=entry.get('reasons',[])
        if isinstance(raw,str):raw=[raw]
        if not raw:raw=['MISSING_REJECTION_REASON']
        for reason in raw:
            cat=str(reason).split(':',1)[0]
            reasons[cat]+=1
            detail.append({'rejection_index':i,'element_id':entry.get('element_id') or '',
                           'artifact_key':entry.get('artifact_key') or '',
                           'reason_category':cat,'reason_detail':str(reason)[:500]})
    ref_rows=list(csv.DictReader(ref.open(encoding='utf-8-sig',newline='')))
    if len(ref_rows)!=30:raise ValueError('Expected 30 Hunk reference rows')
    spans_cache={a['artifact_id']:evidence_spans(a['content']) for a in history}
    feasibility=[]
    for row in ref_rows:
        relation=POSITIVE.get(row['relation_candidate'])
        if not relation:continue
        for atom_id in row['related_atomic_s0_ids'].split(';'):
            atom_id=atom_id.strip()
            if not atom_id:continue
            if atom_id not in element_map:raise ValueError('Unknown atomic S0 ID '+atom_id)
            if row['hunk_id'] not in artifact_map:raise ValueError('Missing evidence hunk '+row['hunk_id'])
            spans=spans_cache[row['hunk_id']]
            ok=[]; fail=Counter()
            for quote in spans:
                passes,why=direct_relevance(element_map[atom_id],quote,relation)
                if passes:ok.append(quote)
                else:fail[why]+=1
            feasibility.append({'hunk_id':row['hunk_id'],'atomic_s0_id':atom_id,'gold_relation':relation,
                         'temporal_basis':row['temporal_basis_inherited_from_event'],
                         'extractable_verbatim_spans':len(spans),
                         'passes_deterministic_relevance_screen':('YES' if ok else 'NO'),
                         'passing_spans':len(ok),'most_common_rejection_reason':(fail.most_common(1)[0][0] if fail else ''),
                         'note':'Necessary precheck only; passing does not guarantee semantic-judge acceptance.'})
    out.mkdir(parents=True)
    def write_csv(name,records,fieldnames):
        with (out/name).open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=fieldnames);w.writeheader();w.writerows(records)
    write_csv('rejection_reasons.csv',[{'reason_category':a,'instances':n} for a,n in reasons.most_common()],['reason_category','instances'])
    write_csv('rejected_interpretations.csv',detail,['rejection_index','element_id','artifact_key','reason_category','reason_detail'])
    write_csv('gold_span_screen_probe.csv',feasibility,list(feasibility[0]) if feasibility else [])
    base=[x for x in feasibility if x['temporal_basis']!='INTERIM_2024']
    summary={
      'status':'READ_ONLY_EXISTING_RUN_DIAGNOSTIC',
      'run_id':receipt['run_id'],
      'artifact_count':len(history),
      'rejected_interpretations':len(rejected),
      'rejection_reason_occurrences':sum(reasons.values()),
      'reason_category_counts':dict(reasons.most_common()),
      'verified_links':len(memory.get('verified_links',[])),
      'source_s0_sha256':f_manifest['s0_sha256'],
      'api_run_report_sha256':sha256(report),
      'gold_positive_exact_triples_all':len(feasibility),
      'gold_triples_with_at_least_one_extracted_span_passing_initial_gate_all':sum(x['passing_spans']>0 for x in feasibility),
      'gold_triples_without_any_extracted_span_passing_initial_gate_all':sum(x['passing_spans']==0 for x in feasibility),
      'gold_positive_exact_triples_baseline':len(base),
      'gold_triples_with_at_least_one_extracted_span_passing_initial_gate_baseline':sum(x['passing_spans']>0 for x in base),
      'gold_triples_without_any_extracted_span_passing_initial_gate_baseline':sum(x['passing_spans']==0 for x in base),
      'limitations':[
       'Gold-based feasibility is an AFTER-RUN offline diagnostic only, never an agent input.',
       'Only spans emitted by evidence_spans are probed; other contiguous quotes could be valid.',
       'Passing the deterministic relevance gate does NOT imply a true relation or passage of the LLM judge.',
       'The reported frozen S0 is not a human-authenticated signature by this script.',
       'The source code is imported from the local project; do not modify project during diagnosis.',
       'Do not tune/verdict-select using these gold labels and then claim held-out performance.'
      ]
    }
    (out/'diagnostic_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2,ensure_ascii=False))
    print('Output:',out)

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('DIAGNOSTIC_ERROR:',exc,file=sys.stderr)
        sys.exit(1)
