from pathlib import Path
import collections
import csv
import hashlib
import io
import json
import re
import shutil
import zipfile

import openpyxl

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'abc_evidence_checkpoint'
OUT.mkdir(exist_ok=True)
ANALYSIS = ROOT / 'abc_delivery_release/analysis'
audit = json.loads((ANALYSIS / 'actual_abc_audit.json').read_text())


def read_sheet(workbook, sheet):
    values = iter(workbook[sheet].values)
    headers = next(values)
    return [dict(excel_row=i, **{h: v for h, v in zip(headers, row)
                                if h and v is not None})
            for i, row in enumerate(values, 2)]


pilot = {}
for reviewer, filename in [(1, 'Source_Review -Result-Review-A.xlsx'),
                           (2, 'Source_Review -Result-Review-B.xlsx')]:
    original_path = ROOT / 'upload' / filename
    workbook = openpyxl.load_workbook(original_path, read_only=True, data_only=True)
    concerns = [r for r in read_sheet(workbook, 'Concerns') if r.get('concern_text')]
    source_log = read_sheet(workbook, 'SourceLog')
    sources = zipfile.ZipFile(ROOT / 'abc_delivery_release/reviewer_archives' /
                             f'reviewer_{reviewer}_phase1_sources.zip')
    quote_checks = []
    for row in concerns:
        packet = sources.read(f"01_sources/pilot/{row['review_id']}.md").decode('utf-8')
        source_lines = collections.defaultdict(dict)
        for source_id, line, text in re.findall(r'^\[(S\d+):L(\d+)\] ?(.*)$', packet, re.M):
            source_lines[source_id][int(line)] = text
        refs = re.findall(r'(S\d+):L(\d+)(?:-L?(\d+))?', row['source_line_refs'])
        valid = bool(refs)
        spans = []
        for source_id, start, end in refs:
            start, end = int(start), int(end or start)
            valid &= end >= start and all(i in source_lines[source_id]
                                          for i in range(start, end + 1))
            spans.append('\n'.join(source_lines[source_id].get(i, '')
                                   for i in range(start, end + 1)))
        quote_checks.append({
            'concern_id': row['concern_id'], 'excel_row': row['excel_row'],
            'valid_line_references': bool(valid),
            'literal_quote_in_cited_span': any(row['exact_source_quote'] in s for s in spans),
        })
    completed = [r for r in source_log if r.get('sources_read') == 'yes'
                 and r.get('concern_list_complete') == 'yes']
    assert len(completed) == 6
    assert all(c['valid_line_references'] and c['literal_quote_in_cited_span']
               for c in quote_checks)
    pilot[f'reviewer_{reviewer}'] = {
        'completed_source_cases': len(completed),
        'submitted_concerns': len(concerns),
        'by_case': dict(collections.Counter(r['review_id'] for r in concerns)),
        'by_priority': dict(collections.Counter(r['priority'] for r in concerns)),
        'literal_quote_checks': quote_checks,
        'disclosure_as_received': read_sheet(workbook, 'Disclosure'),
        'comparative_output_judgments_in_this_workbook': 0,
        'original_sha256': hashlib.sha256(original_path.read_bytes()).hexdigest(),
    }
    raw_dir = OUT / 'originals_unchanged'
    raw_dir.mkdir(exist_ok=True)
    shutil.copyfile(original_path, raw_dir / f'reviewer_{reviewer}_source_pilot_as_received.xlsx')

with (ANALYSIS / 'case_condition_availability.csv').open(encoding='utf-8-sig', newline='') as f:
    availability = list(csv.DictReader(f))
assert len(availability) == 894
by_kind = []
by_group = []
for field, destination in [('kind', by_kind), ('source_group', by_group)]:
    for group in sorted({r[field] for r in availability}):
        for condition in 'ABC':
            rows = [r for r in availability if r[field] == group and r['condition'] == condition]
            destination.append({field: group, 'condition': condition, 'cases': len(rows),
                                'first_complete': sum(r['first_attempt_complete'] == 'True' for r in rows),
                                'eventual_complete': sum(r['eventual_complete'] == 'True' for r in rows),
                                'reported_tokens': sum(int(r['total_recorded_tokens']) for r in rows)})

checkpoint = {
    'status': 'actual_evidence_checkpoint_no_new_human_judgments',
    'new_api_calls': 0,
    'review_stage_status': 'stopped_after_six_source_only_pilot_cases',
    'basis_for_stopping': 'Coordinator reports both reviewers do not wish to continue.',
    'pilot': pilot,
    'pilot_interpretation': '72 submitted concern annotations across the same six cases; not 72 unique concerns and not output-quality ratings.',
    'provenance_notes': {
        'reviewer_1': 'Coordinator reports Alex used AI only for writing. Original Disclosure contains broader/ambiguous AI-generated wording; preserve both records. Independent substantive authorship is not established by the workbook.',
        'reviewer_2': 'NO AI is entered under professional_role; role, experience, relationship and source-review confirmation are missing. Do not infer AI use.',
        'semantic_cautions': [
            'P003-C02: truncated fallback implementation does not establish complete verified behavior.',
            'Reviewer 2 P004-C04: third-party/STL blocks are required after the own header; their position after every other block is not established.',
            'Reviewer 2 P006-C03/C05: testing not documented is not equivalent to testing not performed.',
        ],
        'unchanged_submissions': True,
    },
    'abc_actual': {k: audit[k] for k in ['cases', 'availability', 'all_attempts_usage',
                                       'rejected_attempt_taxonomy', 'fixed_content_B_policy_replay']},
    'by_thread_kind': by_kind,
    'by_source_group': by_group,
    'allowed_conclusions': [
        'Operational availability, recorded token consumption and deterministic structural defects.',
        'Source-only pilot records and literal quote validity.',
        'Retain the earlier 60-case comparative human study separately with its original limitations.',
    ],
    'not_established': [
        'Human semantic comparison of newly generated A/B/C outputs.',
        'Equal realized computation across A/B/C.',
        'Causal semantic correctness or usefulness improvement from gates or inventory.',
        'Human inter-rater agreement from counts of differently segmented concern lists.',
    ],
}
(OUT / 'evidence_checkpoint.json').write_text(json.dumps(checkpoint, ensure_ascii=False, indent=2) + '\n')
shutil.copyfile(ANALYSIS / 'actual_abc_audit.json', OUT / 'verified_abc_execution.json')
shutil.copyfile(ANALYSIS / 'rejected_attempts_taxonomy.csv', OUT / 'rejected_attempts_taxonomy.csv')

table_rows = []
for condition in 'ABC':
    a = audit['availability'][condition]
    u = audit['all_attempts_usage'][condition]
    table_rows.append(f"{condition} & {a['first_attempt_complete_cases']}/298 & {a['eventual_complete_cases']}/298 & {u['recorded_requests']:,} & {u['total_tokens']:,} " + r'\\')
tex = r'''% Verified actual results only. This is an insertion fragment, not a complete paper.
% Keep earlier nine-method and 60-case human results as separate studies.
\subsection{Controlled Structural-Policy Study}
\label{sec:controlled-abc-actual}
We executed three conditions on the same 298 frozen repository cases:
A retained the decision inventory and enforced the structural contracts;
B retained the inventory and recorded contract violations diagnostically;
C used three stages without the inventory. All conditions used the same
model, reasoning setting, stage count, and per-request output limit.
A and B shared prompt templates, while C also changed the inter-stage
representation and instructions. All conditions retained the common
verified-context filter. Thus, B--C evaluates an inventory-and-representation
bundle rather than removal of every source-validation mechanism.

\begin{table}[t]
\centering
\caption{Actual ABC execution on 298 cases. Completion is operational;
reported tokens include all recorded attempts.}
\label{tab:abc-actual-execution}
\begin{tabular}{lrrrr}
\hline
Condition & First & Eventual & Requests & Tokens \\
\hline
''' + '\n'.join(table_rows) + r'''
\hline
\end{tabular}
\end{table}

Condition A completed 259 cases on first attempts and 293 after bounded
retries. B completed all 298 cases on first attempts; C completed 297,
with one HTTP failure subsequently recovered. A's 55 rejected stage attempts
comprised 16 Stage~1 and 39 Stage~3 rejections. Stage~3 trace failures occurred
in 39 attempts, including 23 with coverage failures. Stage~1 provenance and
inventory failures occurred in 14 and 15 attempts, respectively; these
categories overlap. Five A cases remained unavailable after the retry limit.

Enforcement limited release to outputs satisfying the implemented
structural predicates. All 1,341 recommendations in A's accepted final
outputs passed the structural trace check. This is a release-policy property,
not a semantic-correctness assessment. Applying the A predicates to B's
fixed archived chains would accept 257 and reject 41. This retrospective
replay measures policy compliance of existing content; it does not recreate
the generation that would follow an enforced rejection.

The realized computation differed despite common request settings.
A consumed 7.1\% more recorded tokens than B and 22.9\% more than C.
One C error has no reported usage, so its token total covers available
records rather than certified complete billable consumption. These results
characterize structural compliance, availability, and operational cost;
they do not establish a semantic advantage independent of computation.

\subsection{Source-Only Human Pilot}
\label{sec:abc-source-pilot}
Two assessors returned source annotations for the six calibration cases,
covering two discussions, two issues, and two pull requests. They submitted
37 and 35 concern annotations, respectively. Offline checks found all 72
quoted excerpts verbatim within the cited source-line spans. The counts
describe annotations over the same six cases, not distinct cases or an
adjudicated set of unique concerns. Literal quotation checks do not establish
semantic entailment or completeness of the extracted concerns.

Participation ended after source annotation. No comparative judgments of
the new A/B/C outputs were collected, and the planned 60-case main ABC human
study was not completed. The original submissions were retained unchanged.
Assistance declarations were incomplete or ambiguous; the coordinator
reported writing assistance for the first assessor, but the workbook wording
did not cleanly separate writing assistance from substantive annotation.
This pilot is consequently reported as limited source-annotation evidence,
separately from the earlier comparative human study.
'''
(OUT / 'actual_abc_results_insert.tex').write_text(tex)

readme = '''This package records the project's next stage using actual data.

Current decision:
Both reviewer submissions are retained, and their participation is recorded as ending after source review of six pilot cases. No new human scores or judgments have been created. Interpretation issues and missing information remain in the coordinator's notes; the reviewer files have not been edited.

Available evidence:
1. Actual A/B/C execution on 298 cases and its structural analysis.
2. Six shared source-review cases: 37 annotations from the first reviewer and 35 from the second. All 72 quotations appear verbatim within their cited source-line spans.
3. The earlier human study of 60 cases, which must retain its original results and limitations in the paper. This package does not rewrite or replace that study.

Evidence not collected:
Human comparison of the new A/B/C outputs. The source-review forms cannot establish which version is more correct or useful. Different concern counts also do not establish agreement or the superiority of either reviewer.

Files:
actual_abc_results_insert.tex: A LaTeX fragment describing actual results and pilot status for integration into the paper. It is not the complete paper and contains no hypothetical numbers.
evidence_checkpoint.json: Evidence status, quotation checks for both reviewers, analyses by discussion type and source group, and limits on interpretation.
verified_abc_execution.json: The validated analysis of the complete experiment execution.
rejected_attempts_taxonomy.csv: A mechanical classification of 55 rejected attempts. This count is not a semantic judgment.
originals_unchanged/: Original reviewer submissions, retained for the coordinator.

Next step for the paper:
Replace the hypothetical blue A/B/C results with the actual numbers in this package. No A/B/C correctness, semantic coverage, or usefulness scores were collected. Remove claims that those evaluations were completed or explicitly report them as "not collected." Retain the actual results of the earlier 60-case study and the nine-method comparison. The new conclusions concern structural checks, cost, availability, and failures.

No new API requests were sent.
'''
(OUT / 'README_EN.txt').write_text(readme)
manifest = {str(p.relative_to(OUT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(OUT.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
delivery = ROOT / 'output/RationalePath_ABC_Evidence_Checkpoint.zip'
with zipfile.ZipFile(delivery, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file(): z.write(p, Path('RationalePath_ABC_Evidence_Checkpoint') / p.relative_to(OUT))
with zipfile.ZipFile(delivery) as z:
    assert z.testzip() is None
for r in by_kind: print(r)
print(json.dumps({'zip': str(delivery), 'pilot_concerns': [pilot['reviewer_1']['submitted_concerns'], pilot['reviewer_2']['submitted_concerns']],
                  'sha256': hashlib.sha256(delivery.read_bytes()).hexdigest(),
                  'files': len(manifest) + 1, 'new_api_calls': 0}, indent=2))
