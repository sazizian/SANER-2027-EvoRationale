#!/usr/bin/env python3
"""Prepare an auditable, leakage-isolated retrospective development run.

Never edits the frozen reference or the candidate package.  Its adjusted cutoff
is a retrospective retrieval diagnostic, NOT a certified 2024 historical replay.
"""
from __future__ import annotations
import argparse, hashlib, json, csv, shutil, sys
from pathlib import Path
from collections import Counter
from datetime import datetime

S0_NAME = 'S0_ATOMIC_REVIEWER_CONFIRMED.json'
HISTORY_NAME = 'POST_S0_EVIDENCE_RETROSPECTIVE_53.jsonl'
RUNTIME_NAME = 'S0_RETROSPECTIVE_RUNTIME.json'
REFERENCE_NAMES = ['S0_ATOMIC_CANDIDATE.csv', 'COMMIT_SCREENING_CANDIDATE.csv',
                   'EVENT_RELATIONS_CANDIDATE.csv', 'HUNK_RELATIONS_CANDIDATE.csv']
ELEMENT_FIELDS = ('goals','requirements','assumptions','original_evidence',
                  'quality_attributes','constraints_dependencies','implementation_scope')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as fp:
        for chunk in iter(lambda: fp.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()


def load(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def iso(value): return datetime.fromisoformat(value.replace('Z','+00:00'))


def check_file(path, expected, label):
    if not path.is_file(): raise ValueError(f'Missing {label}: {path}')
    actual = sha(path)
    if actual != expected: raise ValueError(f'{label} SHA-256 mismatch: {actual} != {expected}')
    return actual


def code_hash(root):
    paths = sorted((root / 'evorationale').rglob('*.py'))
    if not paths: raise ValueError('Not a v4.1 project root: evorationale/*.py not found')
    h = hashlib.sha256()
    for file in paths:
        rel = file.relative_to(root).as_posix().encode('utf-8')
        h.update(len(rel).to_bytes(4, 'big') + rel)
        h.update(bytes.fromhex(sha(file)))
    return h.hexdigest(), len(paths)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--frozen', type=Path, required=True)
    p.add_argument('--candidate', type=Path, required=True)
    p.add_argument('--code-root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True, help='New, nonexistent run directory')
    a = p.parse_args()
    frozen, candidate, code = a.frozen.resolve(), a.candidate.resolve(), a.code_root.resolve()
    out = a.output.resolve()
    if out.exists(): raise FileExistsError(f'Refusing to overwrite: {out}')
    manifest_file = frozen / 'FREEZE_MANIFEST.json'
    manifest = load(manifest_file)
    if manifest.get('status') != 'DOCUMENTED_SIGNOFF_RECORDED_NOT_INDEPENDENTLY_AUTHENTICATED':
        raise ValueError('Unexpected freeze status')
    if manifest.get('historical_replay_certified') is not False:
        raise ValueError('Unexpected historical certification flag')
    frozen_s0 = frozen / S0_NAME
    frozen_s0_hash = check_file(frozen_s0, manifest['s0_sha256'], 'frozen S0')
    for name in REFERENCE_NAMES:
        check_file(frozen / 'reference' / name, manifest['reference_sha256'][name], name)
    if 'confirmation_file_sha256' in manifest:
        check_file(frozen / 'REVIEWER_CONFIRMATIONS.csv', manifest['confirmation_file_sha256'], 'reviewer confirmations')
    s0 = load(frozen_s0)
    if s0.get('human_approved') is not True: raise ValueError('Frozen S0 is not reviewer-confirmed')
    atomic = [(row['id'],row['text']) for k in ELEMENT_FIELDS for row in s0.get(k, [])]
    if len(atomic) != 18 or len(set(x[0] for x in atomic)) != 18:
        raise ValueError('Expected 18 uniquely identified atomic S0 elements')
    sums = load(candidate / 'SHA256SUMS.json')['files']
    history_src = candidate / 'benchmark_inputs' / HISTORY_NAME
    runtime_source = candidate / 'benchmark_inputs' / 'S0_RUNTIME_RETROSPECTIVE_UNAPPROVED.json'
    check_file(history_src, sums[f'benchmark_inputs/{HISTORY_NAME}'], 'original unlabeled 53-artifact evidence file')
    check_file(runtime_source, sums['benchmark_inputs/S0_RUNTIME_RETROSPECTIVE_UNAPPROVED.json'], 'original retrospective cutoff template')
    retrospective = load(runtime_source)
    for key in (*ELEMENT_FIELDS, 'central_element_ids', 'composite_groups',
                'accepted_at','repository','decision_id'):
        if s0.get(key) != retrospective.get(key):
            raise ValueError(f'Frozen S0 and original retrospective benchmark differ in {key}; do NOT quietly alter S0')
    if iso(retrospective['cutoff_at']) <= iso(s0['cutoff_at']):
        raise ValueError('Retrospective cutoff is not later than original historical window')
    if not retrospective.get('audit_capture_at'):
        raise ValueError('Missing original audit capture timestamp')
    data = [json.loads(line) for line in history_src.read_text(encoding='utf-8').splitlines() if line.strip()]
    kinds = Counter(row['source_type'] for row in data)
    if kinds != {'git_commit_metadata':23, 'git_commit_diff_hunk':30}:
        raise ValueError(f'Unexpected evidence population: {dict(kinds)}')
    if any(set(row).intersection({'gold_label','gold_relation','reference_relation','reviewer_label',
                                  'reviewer_decision','consensus_label'}) for row in data):
        raise ValueError('Unexpected gold/reviewer labels embedded in agent evidence input')
    if any(iso(row['first_auditable_at']) > iso(retrospective['cutoff_at']) for row in data):
        raise ValueError('Retrospective cutoff still excludes captured evidence')
    tree_hash, py_count = code_hash(code)
    # Construct from frozen/confirmed S0: NEVER from the unapproved diagnostic state.
    runtime = dict(s0)
    original_cutoff = s0['cutoff_at']
    runtime['cutoff_at'] = retrospective['cutoff_at']
    runtime['research_label'] = 'DEVELOPMENT_RETROSPECTIVE_CUTOFF_ADJUSTED_NOT_HISTORICAL_REPLAY'
    runtime['runtime_cutoff_audit'] = {
        'description': 'Cutoff changed ONLY for retrospective auditable evidence retrieval',
        'original_frozen_cutoff_at': original_cutoff,
        'retrospective_cutoff_at': runtime['cutoff_at'],
        'first_capture_at': retrospective['audit_capture_at'],
        'frozen_s0_sha256': frozen_s0_hash,
        'original_s0_reviewed_text_preserved': True,
        'historical_replay_certified': False,
    }
    out.mkdir(parents=True)
    (out / 'inputs').mkdir()
    runtime_dest = out / 'inputs' / RUNTIME_NAME
    runtime_dest.write_text(json.dumps(runtime, ensure_ascii=True, sort_keys=True, indent=2)+'\n', encoding='utf-8')
    shutil.copy2(history_src, out / 'inputs' / HISTORY_NAME)
    record = {
        'status': 'READY_FOR_RETROSPECTIVE_OFFLINE_DEVELOPMENT_RUN',
        'frozen_manifest_sha256': sha(manifest_file),
        'frozen_s0_sha256': frozen_s0_hash,
        'frozen_reference_sha256': manifest['reference_sha256'],
        'reviewer_confirmations_sha256': manifest.get('confirmation_file_sha256'),
        'runtime_s0_sha256': sha(runtime_dest),
        'history_sha256': sha(out / 'inputs' / HISTORY_NAME),
        'evorationale_python_tree_sha256': tree_hash,
        'evorationale_python_file_count': py_count,
        'mode_planned': 'offline',
        'artifact_counts': dict(kinds),
        'historical_cutoff_original': original_cutoff,
        'retrospective_cutoff_runtime': runtime['cutoff_at'],
        'historical_replay_certified': False,
        'outcome_gold_available': False,
        'no_gold_reference_files_copied_to_agent_inputs': True,
        'warning': 'Code version/limits must be held fixed before scoring. Offline mode is extractive, not OpenAI-model evidence.',
    }
    (out / 'PREP_MANIFEST.json').write_text(json.dumps(record, sort_keys=True, indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k: record[k] for k in ['status','artifact_counts','frozen_s0_sha256',
        'runtime_s0_sha256','history_sha256','historical_replay_certified']}, indent=2))
    print(f'Inputs: {out / "inputs"}')

if __name__ == '__main__':
    try:main()
    except Exception as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        sys.exit(1)
