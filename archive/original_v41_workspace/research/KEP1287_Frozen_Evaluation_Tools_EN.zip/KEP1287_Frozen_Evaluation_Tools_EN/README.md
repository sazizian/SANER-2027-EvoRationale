# KEP-1287 Frozen-Reference Retrospective Evaluation Tools

English-only helper scripts for the research development (not publication-ready) baseline. No third-party Python dependencies are required by these helpers.

## What this does

1. Verifies the four frozen reference hashes, original frozen S0, confirmation CSV hash, and immutable candidate evidence history.
2. Takes an **isolated runtime copy** of the signed-off 18-element S0. The **only** S0 analytical change is `cutoff_at`, moved from 2024-10-11 to the captured-evidence time in October 2026. The modified copy is **not** a certified historical replay.
3. Copies only the 53 unlabeled evidence artifacts into a fresh evaluation directory. It **never copies the private reference labels to agent inputs**.
4. After EvoRationale's offline CLI is run, scores its verified links against the frozen private hunk reference, computes micro precision, recall, F1 on exact `(hunk ID, S0 ID, relation)` triples, records FP on negative hunks, and writes link-level errors.
5. Computes `baseline` (excludes INTERIM_2024-only hunks) and `all` (all 30 hunks). These are **development baseline metrics**, not held-out or generalizable model performance.

The reviewer confirmation tool checks reported signoffs; it does not authenticate signers. The evaluation does not provide gold architecture outcome classes, full-history recall, or certified historical replay.

## Cursor / PowerShell

The working directory should be the EvoRationale project root with the v4.1 patch, containing `evorationale/`.

Place `KEP1287_Frozen_Evaluation_Tools_EN.zip` into `research` and extract to a **new**, short directory (no overwrite):

```powershell
$py     = Join-Path $env:LOCALAPPDATA 'er4venv\Scripts\python.exe'
$root   = Join-Path $env:LOCALAPPDATA 'ER1287Gold\KEP1287_Gold_Candidate_EN'
$freeze = Join-Path $env:LOCALAPPDATA 'ER1287Gold\KEP1287_Reviewer_Confirmed_Freeze'
$toolDir = Join-Path $env:LOCALAPPDATA 'ER1287EvalTools'
$evalDir = Join-Path $env:LOCALAPPDATA 'ER1287Eval_Offline01'
$env:PYTHONUTF8 = '1'
Test-Path $toolDir
# Only if the result is False:
Expand-Archive -LiteralPath '.\research\KEP1287_Frozen_Evaluation_Tools_EN.zip' -DestinationPath $toolDir
$tools = Join-Path $toolDir 'KEP1287_Frozen_Evaluation_Tools_EN'

# This command checks hashes, then creates a new evaluation directory.
& $py "$tools\prepare_runtime.py" --frozen "$freeze" --candidate "$root" --code-root '.' --output "$evalDir"

# Check output above BEFORE proceeding.
& $py -m evorationale validate `
  --decision "$evalDir\inputs\S0_RETROSPECTIVE_RUNTIME.json" `
  --history "$evalDir\inputs\POST_S0_EVIDENCE_RETROSPECTIVE_53.jsonl"

# Offline deterministic/extractive baseline; no OpenAI API.
& $py -m evorationale run `
  --decision "$evalDir\inputs\S0_RETROSPECTIVE_RUNTIME.json" `
  --history "$evalDir\inputs\POST_S0_EVIDENCE_RETROSPECTIVE_53.jsonl" `
  --output "$evalDir\run" `
  --mode offline --backend local --memory file `
  --memory-dir "$evalDir\checkpoints" `
  --max-rounds 6 --max-queries 12 --max-reads 36 --max-input-tokens 100000

# Only after the run has completed, score against the frozen private reference.
& $py "$tools\score_frozen.py" --frozen "$freeze" --evaluation "$evalDir" --code-root "."

# Display summaries:
Get-Content "$evalDir\score\metrics.json" -Raw
```

Expected preparation: `READY_FOR_RETROSPECTIVE_OFFLINE_DEVELOPMENT_RUN`.
Expected validate: 53 artifact versions and `PASS`.
Expected scorer: `EXPLORATORY_FROZEN_REFERENCE_OFFLINE_BASELINE`.

## Interpretation warnings

- **Never** rename a successful first run as a certified 2024 replay: source retrieval in October 2026 was retrospective.
- The development baseline is text-based. No OpenAI model is involved.
- Metrics are for **30 curated hunks**, not exhaustive historical changes. Screening labels for 23 commits and temporal event labels are separate tasks.
- `REVALIDATE/UNRESOLVED` is not a gold architecture-outcome score.
- Do not tune the code on these labels and then present the same evaluation as held out.
- Preserve the run input hashes and the reviewer-confirmation evidence for a paper artifact.
- If either preparation or scoring fails, **do not bypass the integrity checks**; share the full error output and diagnose it first.
