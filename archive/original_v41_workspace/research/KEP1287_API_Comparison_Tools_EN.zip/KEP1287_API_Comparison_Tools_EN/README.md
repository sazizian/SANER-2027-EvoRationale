# KEP-1287: Frozen-Reference API Development Comparison

This package performs a **separate OpenAI-assisted EvoRationale v4.1 pilot** and scores the completed run against the *same frozen human-consensus reference* as the already-completed deterministic offline baseline. It does not modify the code, the offline run, the frozen S0, or the human labels.

**Important research distinctions:**

- This is a retrospective, curated, single-repository **development** case study, not certified historical replay or held-out generalization.
- Exact-link metrics are `(hunk ID, atomic S0 element ID, relation)` triple matches. The primary `baseline` scope has 24 hunks (excludes `INTERIM_2024`); the `all` scope has 30.
- The API mode changes **query planning, evidence linking, semantic judging, and action planning** together. It is a *full mode comparison*, **not** a controlled linker-only ablation. Differences in F1 cannot be credited to one component.
- No human reference labels are copied into the model's inputs. They are loaded only by `score_api.py` after a completed, hashed run.
- Public GitHub repository text excerpts are sent to OpenAI only when you explicitly start the API run with the acknowledgement flag. API use may incur charges. Never share the API key, even in troubleshooting messages.
- Both configured model IDs are aliases, not guaranteed immutable model snapshots. The run wrapper records the selected IDs, inputs, SHA-256 hashes, budgets and execution times. The receipt is a local record, not an independently authenticated server log.
- Human signoff is recorded but not independently authenticated; architecture-outcome gold labels remain unavailable.

## Files

- `prepare_api.py`: validates offline score and frozen hashes; creates an isolated API experiment using byte-identical S0/evidence inputs.
- `run_api.py`: checks inputs and runs the pinned CLI configuration through your Python environment. Requires explicit approval and an existing `OPENAI_API_KEY` environment variable.
- `score_api.py`: validates API run provenance and scores verified links only **after** successful inference. Prints API/offline metrics side-by-side.
- `score_frozen.py`: exact-triple scoring logic copied unchanged from the offline evaluation package and reused by `score_api.py`.

## PowerShell workflow (run from EvoRationale v4.1 project root)

### 1. Unpack and prepare (no API calls or cost)

Copy `KEP1287_API_Comparison_Tools_EN.zip` to your existing `research` directory in the project.

```powershell
$env:PYTHONUTF8 = "1"
$py = Join-Path $env:LOCALAPPDATA "er4venv\Scripts\python.exe"
$freeze = Join-Path $env:LOCALAPPDATA "ER1287Gold\KEP1287_Reviewer_Confirmed_Freeze"
$evalDir = Join-Path $env:LOCALAPPDATA "ER1287Eval_Offline01"
$apiToolDir = Join-Path $env:LOCALAPPDATA "ER1287ApiTools"
$apiEval = Join-Path $env:LOCALAPPDATA "ER1287Eval_API01"

Test-Path $apiToolDir
Test-Path $apiEval
# Both must be False. If True, STOP; do not overwrite.

Expand-Archive -LiteralPath ".\research\KEP1287_API_Comparison_Tools_EN.zip" -DestinationPath $apiToolDir
$apiTools = Join-Path $apiToolDir "KEP1287_API_Comparison_Tools_EN"

& $py "$apiTools\prepare_api.py" `
  --offline-evaluation "$evalDir" `
  --frozen "$freeze" `
  --code-root "." `
  --output "$apiEval" `
  --model "gpt-5-mini" `
  --judge-model "gpt-5-nano"
```

Expected status: `READY_FOR_RETROSPECTIVE_API_DEVELOPMENT_RUN`. Verify `same_s0_as_baseline`, `same_53_artifacts_as_baseline`, and `code_hash_matches_baseline` are all `true`. **Do not run** if preparation fails.

### 2. Explicitly approve and run the paid hosted-model pilot

The script uses the `OPENAI_API_KEY` variable already in your environment; it does not print it. Do not include your key in chat or terminal screenshots.

```powershell
Write-Host "OPENAI_API_KEY present:" ([bool]$env:OPENAI_API_KEY)
# Only if the key exists and you agree that public-repository excerpts may be sent to the API:
& $py "$apiTools\run_api.py" `
  --evaluation "$apiEval" `
  --code-root "." `
  --i-approve-public-repository-excerpts-to-openai
```

This run may have multiple chargeable requests. You should verify your API account's remaining budget before proceeding. A successful run creates `run/report.json`, `run/manifest.json`, and `RUN_RECEIPT.json`. If it fails, **do not simply rerun the same directory**, because partial checkpoints may exist. Share the non-secret error for diagnosis first.

### 3. Score *after* completed inference (no additional API calls)

```powershell
& $py "$apiTools\score_api.py" `
  --evaluation "$apiEval" `
  --frozen "$freeze" `
  --offline-evaluation "$evalDir" `
  --code-root "."

$m = Get-Content "$apiEval\score\metrics.json" -Raw | ConvertFrom-Json
$m.comparison_with_offline.baseline | Format-List
$m.comparison_with_offline.all | Format-List
```

Expected status: `EXPLORATORY_FROZEN_REFERENCE_HOSTED_MODEL_COMPARISON`.

## Evaluation caveats

The existing offline development benchmark achieved baseline-scope P=0.055556, R=0.071429, F1=0.0625. These are **not expected API results**; they are the frozen offline reference. The API mode must be scored from a genuinely completed API run; no model metrics are provided in this package. A higher or lower score on 24 curated hunks alone does not prove generalization or isolate which component contributed. Human judgment is still required for architecture-level conclusions.

## Test status

This package's preparation, path/hash verification, scoring and comparison logic were exercised using a **local synthetic mode-switched test fixture** to check mechanics. No hosted-model API call was made by this package's author, and **no API accuracy result was claimed**. Your hosted-model run is the first actual model test.
