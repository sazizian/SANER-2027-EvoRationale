#!/usr/bin/env python3
"""Execute an explicit-consent hosted-model EvoRationale run from an immutable API plan.

Requires an existing OPENAI_API_KEY environment variable; never logs its value.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from score_frozen import digest,read,code_tree_hash,matches
from prepare_api import S0,HIST,dump


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--evaluation',type=Path,required=True)
    p.add_argument('--code-root',type=Path,required=True)
    p.add_argument('--i-approve-public-repository-excerpts-to-openai',action='store_true',
                   help='Explicitly acknowledge that repository excerpts will be sent to an external API and billed')
    a=p.parse_args()
    if not a.i_approve_public_repository_excerpts_to_openai:
        raise ValueError('Explicit external text consent flag required; API call not started')
    if not os.environ.get('OPENAI_API_KEY','').strip():
        raise ValueError('OPENAI_API_KEY is missing from this PowerShell session (do not paste the key in chat)')
    if importlib.util.find_spec('openai') is None:
        raise ValueError('OpenAI Python package not installed in the active virtual environment')
    ev=a.evaluation.resolve()
    if (ev/'run').exists() or (ev/'checkpoints').exists() or (ev/'RUN_RECEIPT.json').exists():
        raise FileExistsError('Existing run, checkpoints, or receipt. Refusing to overwrite; prepare a NEW evaluation folder.')
    prep=read(ev/'PREP_MANIFEST.json')
    config=read(ev/'API_CONFIG.json')
    if prep.get('mode_planned')!='api' or prep.get('status')!='READY_FOR_RETROSPECTIVE_API_DEVELOPMENT_RUN':
        raise ValueError('Missing valid API preparation')
    if config.get('protocol')!='PRESPECIFIED_RETROSPECTIVE_API_DEVELOPMENT_COMPARISON':
        raise ValueError('Unexpected API protocol')
    matches(ev/'API_CONFIG.json',prep['api_config_sha256'],'pinned API configuration')
    if code_tree_hash(a.code_root)!=prep['evorationale_python_tree_sha256']:
        raise ValueError('EvoRationale Python code changed since preparation')
    matches(ev/'inputs'/S0,prep['runtime_s0_sha256'],'runtime S0')
    matches(ev/'inputs'/HIST,prep['history_sha256'],'unlabeled evidence')
    b=config['budgets']
    cmd=[sys.executable,'-m','evorationale','run',
         '--decision',str(ev/'inputs'/S0),
         '--history',str(ev/'inputs'/HIST),
         '--output',str(ev/'run'),
         '--mode','api',
         '--allow-repository-text-to-api',
         '--model',config['linker_model'],
         '--judge-model',config['judge_model'],
         '--backend','local','--memory','file',
         '--memory-dir',str(ev/'checkpoints'),
         '--max-rounds',str(b['max_rounds']),
         '--max-queries',str(b['max_queries']),
         '--max-reads',str(b['max_reads']),
         '--max-input-tokens',str(b['max_input_tokens'])]
    print('Starting hosted-model experiment: external API usage may incur charges.',flush=True)
    print('Models:',config['linker_model'],config['judge_model'],flush=True)
    began=datetime.now(timezone.utc).isoformat()
    subprocess.run(cmd,cwd=a.code_root,check=True)
    manifest=read(ev/'run'/'manifest.json')
    if manifest.get('mode')!='api':raise ValueError('Run manifest did not record API mode')
    matches(ev/'run'/'report.json',manifest['report_sha256'],'API report')
    if manifest['decision_sha256']!=prep['runtime_s0_sha256'] or manifest['history_sha256']!=prep['history_sha256']:
        raise ValueError('Executed API run inputs differ from pinned inputs')
    receipt={
      'status':'HOSTED_MODEL_RUN_COMPLETED_AND_HASHED',
      'started_utc':began,'finished_utc':datetime.now(timezone.utc).isoformat(),
      'run_id':manifest['run_id'],'mode':'api',
      'model':config['linker_model'],'judge_model':config['judge_model'],
      'run_manifest_sha256':digest(ev/'run'/'manifest.json'),
      'run_report_sha256':manifest['report_sha256'],
      'api_config_sha256':digest(ev/'API_CONFIG.json'),
      'prep_manifest_sha256':digest(ev/'PREP_MANIFEST.json'),
      'code_tree_sha256':prep['evorationale_python_tree_sha256'],
      'command_without_credentials':cmd,
      'explicit_external_text_consent_received':True,
      'warning':'Receipt records configured aliases/arguments, not provider-side snapshot or reviewer identity.'
    }
    dump(ev/'RUN_RECEIPT.json',receipt)
    print(json.dumps({'status':receipt['status'],'run_id':receipt['run_id'],
                      'output':str(ev/'run'/'report.json')},indent=2),flush=True)

if __name__=='__main__':
    try:main()
    except Exception as ex:
        print(f'ERROR: {ex}',file=sys.stderr)
        sys.exit(1)
