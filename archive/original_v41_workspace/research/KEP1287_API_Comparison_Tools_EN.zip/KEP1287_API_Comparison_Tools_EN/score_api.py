#!/usr/bin/env python3
"""Score a completed API run against a signed-off, hash-checked frozen reference.

Never passes reference labels to the hosted model; scoring is strictly post-run.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import sys
from score_frozen import read,digest,matches,code_tree_hash,evaluate,KNOWN,HUNK_FILE,EVAL_SCOPES
from prepare_api import S0,HIST,dump


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--evaluation',type=Path,required=True)
    p.add_argument('--frozen',type=Path,required=True)
    p.add_argument('--code-root',type=Path,required=True)
    p.add_argument('--offline-evaluation',type=Path,required=True)
    a=p.parse_args()
    ev=a.evaluation.resolve(); frozen=a.frozen.resolve(); off=a.offline_evaluation.resolve()
    prep=read(ev/'PREP_MANIFEST.json'); config=read(ev/'API_CONFIG.json')
    receipt=read(ev/'RUN_RECEIPT.json')
    if prep.get('mode_planned')!='api':raise ValueError('Not an API development preparation')
    matches(ev/'API_CONFIG.json',prep['api_config_sha256'],'API config')
    if code_tree_hash(a.code_root)!=prep['evorationale_python_tree_sha256']:
        raise ValueError('Python code changed since preparation')
    matches(ev/'inputs'/S0,prep['runtime_s0_sha256'],'runtime S0')
    matches(ev/'inputs'/HIST,prep['history_sha256'],'unlabeled evidence')
    matches(frozen/'FREEZE_MANIFEST.json',prep['frozen_manifest_sha256'],'frozen reference manifest')
    fm=read(frozen/'FREEZE_MANIFEST.json')
    matches(frozen/'S0_ATOMIC_REVIEWER_CONFIRMED.json',fm['s0_sha256'],'frozen S0')
    for name, h in fm['reference_sha256'].items():
        matches(frozen/'reference'/name,h,'frozen reference '+name)
    if fm.get('confirmation_file_sha256'):
        matches(frozen/'REVIEWER_CONFIRMATIONS.csv',fm['confirmation_file_sha256'],'reviewer confirmation')
    if receipt.get('status')!='HOSTED_MODEL_RUN_COMPLETED_AND_HASHED' or receipt.get('mode')!='api':
        raise ValueError('No completed API run receipt')
    matches(ev/'RUN_RECEIPT.json',digest(ev/'RUN_RECEIPT.json'),'receipt integrity read')
    matches(ev/'API_CONFIG.json',receipt['api_config_sha256'],'receipt API config')
    matches(ev/'PREP_MANIFEST.json',receipt['prep_manifest_sha256'],'receipt prep')
    if receipt['code_tree_sha256']!=prep['evorationale_python_tree_sha256']:
        raise ValueError('Receipt code tree mismatch')
    if receipt['model']!=config['linker_model'] or receipt['judge_model']!=config['judge_model']:
        raise ValueError('Configured model mismatch')
    matches(ev/'run'/'manifest.json',receipt['run_manifest_sha256'],'recorded API run manifest')
    rm=read(ev/'run'/'manifest.json')
    matches(ev/'run'/'report.json',rm['report_sha256'],'API report')
    if rm['report_sha256']!=receipt['run_report_sha256'] or rm.get('mode')!='api' or rm.get('run_id')!=receipt.get('run_id'):
        raise ValueError('Run receipt and report mismatch')
    if rm.get('decision_sha256')!=prep['runtime_s0_sha256'] or rm.get('history_sha256')!=prep['history_sha256']:
        raise ValueError('API run input provenance mismatch')
    matches(off/'PREP_MANIFEST.json',prep['baseline_prep_sha256'],'original offline preparation')
    matches(off/'score'/'metrics.json',prep['baseline_score_sha256'],'original offline metrics')
    baseline=read(off/'score'/'metrics.json')
    if baseline.get('run_sha256')!=prep['baseline_run_report_sha256']:
        raise ValueError('Baseline metrics and run report mismatch')
    if baseline.get('status')!='EXPLORATORY_FROZEN_REFERENCE_OFFLINE_BASELINE':
        raise ValueError('Unexpected offline baseline status')
    if read(off/'PREP_MANIFEST.json')['runtime_s0_sha256']!=prep['runtime_s0_sha256'] or read(off/'PREP_MANIFEST.json')['history_sha256']!=prep['history_sha256']:
        raise ValueError('API / offline comparison inputs differ')
    with (frozen/'reference'/HUNK_FILE).open(encoding='utf-8-sig',newline='') as fp:
        labels=list(csv.DictReader(fp))
    if len(labels)!=30 or len({x['hunk_id'] for x in labels})!=30:
        raise ValueError('Expected 30 unique human-adjudicated hunk labels')
    if any(r['relation_candidate'] not in KNOWN for r in labels):raise ValueError('Unknown hunk relation value')
    report=read(ev/'run'/'report.json')
    out={
      'status':'EXPLORATORY_FROZEN_REFERENCE_HOSTED_MODEL_COMPARISON',
      'run_id':rm['run_id'],'run_mode':'api',
      'configured_models':{'linker':config['linker_model'],'judge':config['judge_model']},
      'report_outcome':report.get('recommended_outcome'),
      'verification_status':(report.get('verification') or {}).get('status'),
      'run_sha256':rm['report_sha256'],'frozen_s0_sha256':fm['s0_sha256'],
      'historical_replay_certified':False,'gold_decision_outcomes_available':False,
      'notes':['Same frozen S0, selected evidence population, thresholds and scorer as offline baseline',
               'API mode differs in multiple components, not just linking; this is not an ablation',
               'Development-set pilot only, not held-out generalization',
               'Configured model aliases may not be immutable snapshots'],
      'results':{},'comparison_with_offline':{}
    }
    errors=[]
    for scope in EVAL_SCOPES:
        summary, rows=evaluate(labels,report,scope)
        summary['limitations']=[x for x in summary['limitations'] if 'offline mode' not in x]
        summary['limitations'] += ['API mode alters planning/linking/semantic judgment/action planning',
                                   'model aliases not provider-snapshot verified']
        out['results'][scope]=summary
        b=baseline['results'][scope]
        if b['gold_positive_exact_triples']!=summary['gold_positive_exact_triples'] or b['evaluated_hunks']!=summary['evaluated_hunks']:
            raise ValueError('Gold evaluation population shifted')
        out['comparison_with_offline'][scope]={
          'offline_f1':b['f1'],'api_f1':summary['f1'],
          'delta_f1':round(summary['f1']-b['f1'],6),
          'offline_precision':b['precision'],'api_precision':summary['precision'],
          'offline_recall':b['recall'],'api_recall':summary['recall']
        }
        errors.extend(rows)
    score=ev/'score'
    if score.exists():raise FileExistsError(f'Refusing to overwrite an existing score: {score}')
    score.mkdir()
    dump(score/'metrics.json',out)
    with (score/'link_errors.csv').open('w',encoding='utf-8',newline='') as fp:
        cols=['scope','verdict','hunk_id','atomic_s0_id','relation','reference_hunk_relation','temporal_basis']
        w=csv.DictWriter(fp,fieldnames=cols);w.writeheader();w.writerows(errors)
    print(json.dumps({'status':out['status'], 'results':out['results'],
                      'comparison_with_offline':out['comparison_with_offline'],
                      'output':str(score)},indent=2))

if __name__=='__main__':
    try:main()
    except Exception as ex:
        print(f'ERROR: {ex}',file=sys.stderr)
        sys.exit(1)
