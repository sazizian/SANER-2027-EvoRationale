#!/usr/bin/env python3
"""Prepare an isolated, hash-linked API comparison from an already scored offline run.

Does not access hosted APIs, change EvoRationale code, or copy gold labels into inputs.
"""
from __future__ import annotations
import argparse
from collections import Counter
from pathlib import Path
import hashlib
import json
import shutil
import sys
from score_frozen import digest, read, code_tree_hash, matches

S0 = 'S0_RETROSPECTIVE_RUNTIME.json'
HIST = 'POST_S0_EVIDENCE_RETROSPECTIVE_53.jsonl'
BASE_STATUS = 'EXPLORATORY_FROZEN_REFERENCE_OFFLINE_BASELINE'

def dump(path: Path, obj: dict):
    path.write_text(json.dumps(obj,sort_keys=True,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--offline-evaluation', type=Path, required=True)
    p.add_argument('--frozen', type=Path, required=True)
    p.add_argument('--code-root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--model', default='gpt-5-mini')
    p.add_argument('--judge-model', default='gpt-5-nano')
    args=p.parse_args()
    off=args.offline_evaluation.resolve()
    freeze=args.frozen.resolve()
    out=args.output.resolve()
    if out.exists():raise FileExistsError(f'Refusing to overwrite existing evaluation directory: {out}')
    if args.model==args.judge_model:raise ValueError('Linker model and independently configured judge model must differ for this protocol')
    if not args.model.strip() or not args.judge_model.strip():raise ValueError('Both model names are required')
    prep=read(off/'PREP_MANIFEST.json')
    if prep.get('mode_planned')!='offline':raise ValueError('Source preparation is not the pinned offline baseline')
    if prep.get('historical_replay_certified') is not False:raise ValueError('Unexpected certification status')
    if prep.get('artifact_counts')!={'git_commit_metadata':23,'git_commit_diff_hunk':30}:
        raise ValueError('Unexpected artifact population')
    tree=code_tree_hash(args.code_root)
    if tree!=prep['evorationale_python_tree_sha256']:
        raise ValueError('EvoRationale Python code differs from baseline; no controlled comparison')
    f_manifest=read(freeze/'FREEZE_MANIFEST.json')
    matches(freeze/'FREEZE_MANIFEST.json',prep['frozen_manifest_sha256'],'frozen manifest')
    matches(freeze/'S0_ATOMIC_REVIEWER_CONFIRMED.json',prep['frozen_s0_sha256'],'frozen S0')
    for name,expected in f_manifest['reference_sha256'].items():
        matches(freeze/'reference'/name,expected,'frozen reference '+name)
    if f_manifest.get('confirmation_file_sha256'):
        matches(freeze/'REVIEWER_CONFIRMATIONS.csv',f_manifest['confirmation_file_sha256'],'reviewer confirmation')
    matches(off/'inputs'/S0,prep['runtime_s0_sha256'],'offline runtime S0')
    matches(off/'inputs'/HIST,prep['history_sha256'],'offline input evidence')
    mr=read(off/'run'/'manifest.json')
    matches(off/'run'/'report.json',mr['report_sha256'],'offline report')
    if mr.get('mode')!='offline' or mr.get('decision_sha256')!=prep['runtime_s0_sha256'] or mr.get('history_sha256')!=prep['history_sha256']:
        raise ValueError('Offline run did not use the prepared inputs')
    metrics=read(off/'score'/'metrics.json')
    if metrics.get('status')!=BASE_STATUS or metrics.get('run_sha256')!=mr['report_sha256']:
        raise ValueError('Offline baseline score/report mismatch')
    data=[json.loads(line) for line in (off/'inputs'/HIST).read_text(encoding='utf-8').splitlines() if line.strip()]
    if len(data)!=53 or Counter(row.get('source_type') for row in data)!= {'git_commit_metadata':23,'git_commit_diff_hunk':30}:
        raise ValueError('Unexpected evidence input population')
    forbidden={'gold_label','gold_relation','reference_relation','reviewer_label','reviewer_decision','consensus_label'}
    if any(forbidden.intersection(row) for row in data): raise ValueError('Reviewer labels found in agent input')
    conf={
      'protocol':'PRESPECIFIED_RETROSPECTIVE_API_DEVELOPMENT_COMPARISON',
      'mode':'api', 'linker_model':args.model,'judge_model':args.judge_model,
      'retrieval_backend':'local', 'memory_backend':'file',
      'embedding_revision':'', 'alloy_jar':'',
      'budgets':{'max_rounds':6,'max_queries':12,'max_reads':36,'max_input_tokens':100000},
      'requires_explicit_external_text_consent':True,
      'model_aliases_not_guaranteed_snapshot_pinned':True,
      'api_mode_changes_planner_linker_judge_and_action_planner':True,
      'notes':'Do not edit after preparation. The reference file is never passed to agent.'
    }
    out.mkdir(parents=True)
    (out/'inputs').mkdir()
    shutil.copy2(off/'inputs'/S0,out/'inputs'/S0)
    shutil.copy2(off/'inputs'/HIST,out/'inputs'/HIST)
    dump(out/'API_CONFIG.json',conf)
    api_prep={**prep,
      'status':'READY_FOR_RETROSPECTIVE_API_DEVELOPMENT_RUN',
      'mode_planned':'api',
      'baseline_prep_sha256':digest(off/'PREP_MANIFEST.json'),
      'baseline_run_report_sha256':mr['report_sha256'],
      'baseline_score_sha256':digest(off/'score'/'metrics.json'),
      'api_config_sha256':digest(out/'API_CONFIG.json'),
      'historical_replay_certified':False,
      'no_gold_reference_files_copied_to_agent_inputs':True,
      'warning':'Changes multiple agent components, not a linker-only ablation. Model aliases may drift.'
    }
    dump(out/'PREP_MANIFEST.json',api_prep)
    matches(out/'inputs'/S0,prep['runtime_s0_sha256'],'copied runtime S0')
    matches(out/'inputs'/HIST,prep['history_sha256'],'copied unlabeled history')
    print(json.dumps({
       'status':api_prep['status'],
       'models':{'linker':conf['linker_model'],'judge':conf['judge_model']},
       'same_s0_as_baseline':True,'same_53_artifacts_as_baseline':True,
       'code_hash_matches_baseline':True,
       'gold_labels_in_agent_inputs':False,
       'historical_replay_certified':False,
       'output':str(out)
    }, indent=2))

if __name__=='__main__':
    try:main()
    except Exception as ex:
        print(f'ERROR: {ex}',file=sys.stderr)
        sys.exit(1)
