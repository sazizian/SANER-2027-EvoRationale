#!/usr/bin/env python3
"""Check the integrity and intentionally unapproved status of the KEP-1287 review kit."""
from pathlib import Path
import csv, hashlib, json, sys

ROOT = Path(__file__).resolve().parents[1]
def digest(data): return hashlib.sha256(data).hexdigest()
def git_blob(data):return hashlib.sha1((f"blob {len(data)}\0").encode() + data).hexdigest()
def rowcount(path):
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        return len(list(csv.DictReader(fh)))
def main():
    p = json.loads((ROOT / "PROVENANCE_AND_READINESS.json").read_text(encoding="utf-8"))
    s = ROOT / "source_capture"
    data1 = (s / "baseline_README_2023.md").read_bytes()
    data2 = (s / "baseline_kep_2023.yaml").read_bytes()
    assert digest(data1) == p["baseline_readme_sha256"]
    assert digest(data2) == p["baseline_kep_yaml_sha256"]
    assert git_blob(data1) == p["baseline_readme_git_blob_sha1"]
    assert git_blob(data2) == p["baseline_kep_yaml_git_blob_sha1"]
    mf = json.loads((s / "capture_manifest.json").read_text(encoding="utf-8"))
    assert mf["baseline_commit"] == p["baseline_commit"]
    assert rowcount(s / "all_readme_commits_in_window.csv") == p["timeline_rows"] == 23
    assert rowcount(ROOT / "reference_tables" / "S0_Candidate_Statements.csv") == p["draft_s0_element_count"] == 12
    assert rowcount(ROOT / "reference_tables" / "Four_Curated_Events_Researcher_Notes.csv") == p["selected_diffs"] == 4
    assert rowcount(ROOT / "reference_tables" / "Patch_Hunk_Index.csv") == p["selected_diff_hunks"]
    assert not any(p[k] for k in ("gold_labels_present", "human_approved_s0", "historical_replay_certified", "first_approval_event_verified"))
    draft = json.loads((ROOT / "draft_s0" / "S0_KEP1287_2023_UNAPPROVED.json").read_text(encoding="utf8"))
    assert draft["human_approved"] is False
    assert draft["baseline_git_commit"] == p["baseline_commit"]
    for reviewer in ("Reviewer_A", "Reviewer_B"):
        d = ROOT / "reviewers" / reviewer
        assert rowcount(d / "S0_Review.csv") == 12
        assert rowcount(d / "Selected_Event_Review.csv") == 4
        assert rowcount(d / "Hunk_Review.csv") == p["selected_diff_hunks"]
    print(json.dumps({"status":"PASS","baseline_sha256_and_git_blobs":"VERIFIED", "s0_candidates":12, "timeline_commits":23, "selected_diff_commits":4, "indexed_patch_hunks":p["selected_diff_hunks"], "s0_human_approved":False,"gold_labels_present":False}, indent=2))
if __name__ == "__main__":
    try:main()
    except Exception as e:
        print(json.dumps({"status":"FAIL","reason":str(e)}, indent=2));sys.exit(1)
