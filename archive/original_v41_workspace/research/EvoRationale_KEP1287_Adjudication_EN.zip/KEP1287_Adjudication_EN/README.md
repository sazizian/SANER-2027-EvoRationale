# EvoRationale KEP-1287: Historical S0 adjudication kit

**All package files, names, instructions, data and code are in English.**

## What this package is

A review-ready, **unadjudicated** research kit for a pinned 2023 Kubernetes KEP-1287 revision and a bounded 2024 follow-up interval. It is not a final ground truth data set and does not establish full historical replay validity.

- Baseline repository: `kubernetes/enhancements`
- Baseline commit: `5950905de89aab2be202d28b823701276cbefea0` (2023-10-26T15:17:39Z)
- Baseline document status at that revision: `implementable`, stage `alpha`
- Window end (exclusive): `2024-10-11T00:00:00Z`
- Sources: pinned historical README and `kep.yaml`, 23 commit metadata records, four selected commit diffs.
- Review objects: 12 candidate S0 statements, four curated events, and 30 patch hunks.

## Folder guide

- `source_capture/` contains a byte-for-byte copy of the uploaded capture (including original manifest, baseline files, 23-commit CSV and four detailed diffs). These are source materials: do not edit.
- `draft_s0/S0_KEP1287_2023_UNAPPROVED.json` contains the **existing unapproved** initial S0 proposal. Its `accepted_at` is only a dated observation snapshot proxy; it is **not a verified first-acceptance event**.
- `reference_tables/All_23_Commits_Screening.csv` lists all 23 commit metadata records. Only four have detailed diffs in this archive.
- `reference_tables/Four_Curated_Events_Researcher_Notes.csv` includes source-grounded initial observations and questions, **not adjudicated labels**.
- `reference_tables/Patch_Hunk_Index.csv` indexes patch hunks and includes keyword-derived candidate element IDs, **not semantic verdicts**.
- `reviewers/Reviewer_A/` and `reviewers/Reviewer_B/` hold **separate blank review sheets** for independent annotation.
- `adjudication/` contains consensus templates to complete only after independent review.
- `scripts/check_package.py` verifies the source document digests, table row counts, and the no-gold/no-approval flags.

## The next action on Windows (Cursor)

Extract this ZIP into your existing `EvoRationale_PaperAligned_v4\research` folder. It will create a `KEP1287_Adjudication_EN` subdirectory. Run:

```powershell
$py = Join-Path $env:LOCALAPPDATA "er4venv\Scripts\python.exe"
$env:PYTHONUTF8 = "1"
& $py .\research\KEP1287_Adjudication_EN\scripts\check_package.py
```

Then open `reviewers/Reviewer_A/S0_Review.csv` in Excel and inspect the 12 statements against the source links, recording `ACCEPT`, `REWRITE`, `REJECT` or `NEEDS_CONTEXT`. **Do not simply set `human_approved` to true.** A second independent reviewer should annotate `Reviewer_B` before gold-label adjudication.

Review the four selected events separately in `Selected_Event_Review.csv`. You may use `SUPPORTS`, `WEAKENS`, `CONTRADICTS`, `SUPERSEDES`, `IMPLEMENTATION_ONLY`, `UNRELATED` or `UNKNOWN`. Keep claims about 2023 S0 distinct from successive changes to the 2024 intermediate state.

## Research limitations

1. The baseline's first approval event remains unverified. A reproducible 2023 Git revision is not automatically the acceptance date.
2. Only four selected diffs, not all 23, are in the capture. No empirical recall, precision or F1 scores can be derived from these sheets.
3. Two reviewers and a written adjudication protocol are required to establish independent labels. Blank sheets do not constitute completed independent assessment.
4. A beta-scope deferral is not necessarily a rejection of the long-term architectural rationale. The September and October 2024 policy wording changes must be read in chronological order.
5. Do not feed human labels, event summaries, or later KEP revisions into the agent's S0 input or retrieval context as if they were available in 2023.
6. No original EvoRationale code, Azure data, or previous outputs are modified by this package.

## Provenance

The `PROVENANCE_AND_READINESS.json` file records source hashes and limitations. All candidate judgments are explicitly marked preliminary.
