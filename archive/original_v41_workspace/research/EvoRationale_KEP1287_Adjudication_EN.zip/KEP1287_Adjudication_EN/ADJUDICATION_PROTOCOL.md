# Independent coding protocol

## Unit of analysis

Two distinct units are used: (1) an S0 rationale element in the pinned historical KEP and (2) a post-S0 Git event or specific changed hunk. Do not count multiple hunks from one commit as independent design decisions or independent reviewers.

## Stage A — Validate the baseline

1. Confirm pinned commit, README SHA-256 and Git blob SHA-1, YAML SHA-256 and Git blob SHA-1.
2. Confirm all S0 propositions using the exact 2023 snapshot; do not use later edits to rewrite what was originally documented.
3. Determine whether the selected snapshot is an observation baseline or an actual accepted decision. This kit documents an observation snapshot only.
4. Distinguish statements of motivation/constraints from implementation plans and expected future behavior.
5. Record per-element `ACCEPT`, `REWRITE`, `REJECT` or `NEEDS_CONTEXT`, with an explicit source anchor and explanation.

## Stage B — Screen the post-S0 timeline

1. Read `All_23_Commits_Screening.csv` before drawing conclusions about four selected changes. Sixteen or more unreviewed commits may affect the causal interpretation of a selected change.
2. Use exact immutable commit SHA, file name, hunk, commit date, and source URL. The capture time is not the event time.
3. For the four selected events, evaluate relevance **to the 2023 S0**. Also record changes to *intermediate 2024 proposals* separately. For example, append-only versus mutable ResizePolicy text changes may be a 2024 revision without contradicting the less-specific 2023 S0.
4. Do not infer a reason for a design change solely from a commit title, code diff or feature-gate update.

## Stage C — Review categories

**S0 verdicts:** `ACCEPT`, `REWRITE`, `REJECT`, `NEEDS_CONTEXT`.

**Evidence relation:** `SUPPORTS`, `WEAKENS`, `CONTRADICTS`, `SUPERSEDES`, `IMPLEMENTATION_ONLY`, `UNRELATED`, `UNKNOWN`.

**Temporal comparison:** state whether the proposed relation is to the pinned 2023 baseline or to a later interim 2024 state. A change to beta scope or an intermediate draft need not imply architectural failure.

**Drift type:** record only when supported by the cited artifact and rationale element; otherwise `UNKNOWN`.

## Stage D — Reviewer independence

Reviewers A and B complete separate copies before inspecting each other's annotations. Disagreements are then resolved using the `adjudication/` templates; preserve the original unmodified reviewer files. Every final label should have an explanation, source URL, hunk ID, and adjudicator identifier.

## Leakage prevention and benchmark readiness

Do not expose adjudicated event labels, 2024 content or later rationale edits to the S0 builder. Model predictions must be frozen before blind gold-label review, or evaluated against independently held-out examples. This package contains **no finalized gold labels**. Only after explicit human approval, temporal and history verification, and label completion should a compatible EvoRationale JSONL episode be generated and benchmarked.
