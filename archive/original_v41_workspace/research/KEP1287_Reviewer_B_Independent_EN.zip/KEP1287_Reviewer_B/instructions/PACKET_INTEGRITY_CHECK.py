"""Check the self-contained Reviewer B packet. Uses Python standard library only."""
import csv, hashlib, json
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
EXPECTED={'S0_Review.csv':12,'Timeline_Screening.csv':23,'Selected_Event_Review.csv':4,'Hunk_Review.csv':30}
for filename,n in EXPECTED.items():
    with (BASE/'forms'/filename).open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    assert len(rows)==n,(filename,len(rows),n)
with (BASE/'sources/SOURCE_INDEX.csv').open(encoding='utf-8-sig',newline='') as f:
    sources=list(csv.DictReader(f))
for r in sources:
    p=BASE/r['local_file']
    assert p.is_file(),str(p)
    assert hashlib.sha256(p.read_bytes()).hexdigest()==r['file_sha256'],str(p)
manifest=json.loads((BASE/'sources/capture_manifest.json').read_text(encoding='utf-8'))
assert manifest['baseline_readme_sha256']==hashlib.sha256((BASE/'sources/S0_README_2023.md').read_bytes()).hexdigest()
assert manifest['baseline_kep_yaml_sha256']==hashlib.sha256((BASE/'sources/S0_kep_2023.yaml').read_bytes()).hexdigest()
assert not any(BASE.rglob('*Reviewer_A*'))
for filename in EXPECTED:
    with (BASE/'forms'/filename).open(encoding='utf-8-sig',newline='') as f:
        records=list(csv.DictReader(f))
    for row in records:
        for field in ('reviewer_id','reviewer_reason','review_date_utc'):
            if field in row:
                assert not row[field].strip(), f'Existing reviewer response found in {filename}: {field}'
        for field in ('reviewer_verdict','screening_decision','reviewer_evidence_relation','reviewer_relation'):
            if field in row:
                assert row[field]=='UNDECIDED', f'Pre-filled label found in {filename}: {field}'

print(json.dumps({'status':'PASS','baseline_hashes':'MATCH','sources':len(sources),'review_forms':EXPECTED},indent=2))
