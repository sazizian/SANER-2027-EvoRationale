# Instructions for Independent Reviewer B

Thank you for reviewing this research dataset. Please work independently: **do not discuss individual labels with Reviewer A or examine any previous automated model predictions** until both reviews have been submitted.

## Your assignment and order of work

### Phase 1 — 2023 S0 rationale validation (first and highest priority)

1. Open `sources/S0_README_2023.md` and `sources/S0_kep_2023.yaml`. Treat only these frozen 2023 files as the basis for S0. The pinned link is also included in every CSV row.
2. Open `forms/S0_Review.csv` in Excel. Evaluate **all 12** candidate elements independently. The elements include goals, assumptions, requirements, quality attributes, constraints, and implementation scope.
3. For each row, check the proposed statement against the cited 2023 lines. Record one of `ACCEPT`, `REWRITE`, `REJECT`, or `NEEDS_CONTEXT` in `reviewer_verdict`. Record the **exact text or line anchor**, your reason, and a proposed corrected statement when using `REWRITE`.
4. Enter a consistent `reviewer_id` (for example `B`) and `review_date_utc` (ISO 8601 date such as `2026-10-11`). The source-derived columns should not be edited.

**Decision rule:** `ACCEPT` means the 2023 source supports the exact meaning and granularity of the proposed statement; it is **not** a judgment that the decision is optimal today. `REWRITE` means a supported idea is misphrased, overstated, or contains two separate claims. `REJECT` means the fixed 2023 sources do not warrant the statement. `NEEDS_CONTEXT` means it cannot yet be decided, with the missing evidence explained.

### Phase 2 — bounded 2024 change screening

5. Open `forms/Timeline_Screening.csv`. The 23 rows give timestamps, commit summaries, and official GitHub URLs. Use the choices `POTENTIALLY_RELEVANT`, `NOT_RELEVANT`, `NEEDS_DIFF`, or `UNCERTAIN` for `screening_decision`. In notes, state why the change might bear on a documented S0 element. If you have only a title and no detailed patch, **do not treat that title as proof of drift**.
6. Open `forms/Selected_Event_Review.csv` and the four matching files in `sources/diffs/`. Label each **specific event-to-S0 relationship** using `SUPPORTS`, `WEAKENS`, `CONTRADICTS`, `SUPERSEDES`, `IMPLEMENTATION_ONLY`, `UNRELATED`, or `UNKNOWN`. Supply the relevant S0 element IDs and patch hunk IDs (from `forms/Hunk_Review.csv`).
7. For `reviewer_temporal_basis` use `BASELINE_2023`, `INTERIM_2024`, `BOTH`, or `UNKNOWN`. If a patch reverses an interim 2024 wording but does **not** contradict 2023 S0, explain that explicitly. Use `UNKNOWN` rather than guess a drift type.
8. Complete `forms/Hunk_Review.csv`, linking the 30 changes to a baseline element **only if there is direct support**. Read the **full patch** in `sources/diffs/` whenever a preview is truncated. Empty evidence links or `UNRELATED` are acceptable.

### How to preserve independence

- Do not use newer versions of the KEP when validating the **2023 baseline**. It is permissible to consult the dated 2024 commit URLs for Phase 2 only.
- Do not copy or infer the researcher's intended labels. The candidate S0 statements and selected diffs are **review items**, not adjudicated truth.
- Separate a change to a later *intermediate* policy or rollout plan from a contradiction of the original 2023 rationale.
- Do not infer motives or causal explanations from a commit title alone. Record `UNKNOWN` or `NEEDS_DIFF` if the evidence is insufficient.
- If a proposition contains multiple claims, recommend splitting or rewriting rather than assuming full support from partial evidence.
- Do not edit `sources/`, commit SHA values, baseline URLs, or historical timestamps.

### Files to send back

Please return `S0_Review.csv`, `Timeline_Screening.csv`, `Selected_Event_Review.csv`, and `Hunk_Review.csv` from `forms/`, plus any open questions or corrections. If you complete only Phase 1, return `S0_Review.csv` and specify the uncompleted phases. Do not rename IDs or edit canonical source files.

For permitted values, see `instructions/REVIEW_LABEL_GUIDE.md`. For file verification, see `instructions/REVIEWER_RETURN_CHECKLIST.md`.
